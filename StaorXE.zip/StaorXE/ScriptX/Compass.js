"ui";

// 导入UI缩放管理器
const UIScaleManager = require('UIScaleManager');

// 使用全屏布局确保居中
ui.layout(
    <frame gravity="center" bg="#FFFFFF">
        <!-- 顶部状态条 - 现在在最顶部 -->
        <vertical>
        <View h={UIScaleManager.size(30)} bg="#009688"/>
        <text 
                    gravity="center"
                    bg="#009688"
                    textSize={UIScaleManager.textSize(30)}
                    textColor="#ffffff" 
                    textStyle="bold" 
                    text="方向检测"
                />
        <View h={UIScaleManager.size(30)} bg="#009688"/>
        </vertical>
        <vertical gravity="center" layout_gravity="center">
            <!-- 圆形卡片 - 严格居中 -->
            <card 
                w={UIScaleManager.size(280)} 
                h={UIScaleManager.size(280)} 
                cardCornerRadius={UIScaleManager.size(140)} 
                cardElevation={UIScaleManager.size(10)} 
                gravity="center" 
                layout_gravity="center"
                cardBackgroundColor="#FFFFFF">
                
                <vertical gravity="center" padding={UIScaleManager.margin(16)}>
                    <text id="directionText" 
                          textSize={UIScaleManager.textSize(24) + 'sp'} 
                          gravity="center" 
                          textColor="#9C27B0" 
                          textStyle="bold" 
                          text="西"/>
                    <text id="degreeText" 
                          textSize={UIScaleManager.textSize(20) + 'sp'} 
                          gravity="center" 
                          margin={UIScaleManager.margin(2, 0, 0, 0)} 
                          textColor="#607D8B" 
                          text="277°"/>
                </vertical>
            </card>
        </vertical>
    </frame>
);

// 禁止横屏
ui.emitter.on("config_changed", function(newConfig) {
    if (newConfig.orientation !== android.content.res.Configuration.ORIENTATION_PORTRAIT) {
        // 强制设置为竖屏
        activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }
});

// 初始设置为竖屏
activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

// 方向传感器逻辑（保持原有功能）
var directions = ["北", "东北", "东", "东南", "南", "西南", "西", "西北"];
var colorStrings = ["#F44336","#FF9800","#FFEB3B","#4CAF50","#2196F3","#3F51B5","#9C27B0","#E91E63"];

if (typeof sensors !== 'undefined' && sensors.register) {
    var sensorListener = sensors.register("orientation", sensors.delay.ui).on("change", function(event) {
        var degree = Math.round(event.values[0]);
        var index = Math.round((degree % 360) / 45) % 8;
        ui.run(() => {
            ui.directionText.setText(directions[index]);
            ui.directionText.setTextColor(android.graphics.Color.parseColor(colorStrings[index]));
            ui.degreeText.setText(degree + "°");
        });
    });
}
