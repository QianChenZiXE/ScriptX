//关联Delete.js-Create.js
var i = dialogs.select("传输方向", "1. Sdcard / Data", "2. Data / Sdcard", "3. Delete + Data");

switch (i) {
    case 0:
        // 源目录路径
        var sourceDir = "/sdcard/ScriptX/";
        // 目标目录路径
        var targetDir = "/data/user/0/S.cript.X/files/project/ScriptX/";

        // 确保目标目录存在，如果不存在则创建（包括父目录）
        ensureDirExists(targetDir);

        // 复制目录及其内容的函数
        function copyDir(source, target) {
            var filesList = files.listDir(source);
            for (var j = 0; j < filesList.length; j++) {
                var filePath = source + filesList[j];
                var targetPath = target + filesList[j];
                if (files.isDir(filePath)) {
                    ensureDirExists(targetPath);
                    copyDir(filePath, targetPath);
                } else {
                    try {
                        files.copy(filePath, targetPath);
                        console.log("文件 " + filePath + " 复制成功到 " + targetPath);
                    } catch (error) {
                        console.error("文件 " + filePath + " 复制失败: ", error);
                    }
                }
            }
        }

        // 调用函数开始复制目录
        copyDir(sourceDir, targetDir);
        toast("执行成功")
        engines.execScriptFile("Delete.js");
        break;
    case 1:
        engines.execScriptFile("Create.js");
        // 源目录路径
        var sourceDir = "/data/user/0/S.cript.X/files/project/ScriptX/";
        // 目标目录路径
        var targetDir = "/sdcard/ScriptX/";

        // 确保目标目录存在，如果不存在则创建（包括父目录）
        ensureDirExists(targetDir);

        // 复制目录及其内容的函数
        function copyDir(source, target) {
            var filesList = files.listDir(source);
            for (var j = 0; j < filesList.length; j++) {
                var filePath = source + filesList[j];
                var targetPath = target + filesList[j];
                if (files.isDir(filePath)) {
                    ensureDirExists(targetPath);
                    copyDir(filePath, targetPath);
                } else {
                    try {
                        files.copy(filePath, targetPath);
                        console.log("文件 " + filePath + " 复制成功到 " + targetPath);
                    } catch (error) {
                        console.error("文件 " + filePath + " 复制失败: ", error);
                    }
                }
            }
        }

        // 调用函数开始复制目录
        copyDir(sourceDir, targetDir);
        toast("执行成功")
        break;
    case 2:
        // 指定要操作的文件夹路径
const folderPath = "/data/user/0/S.cript.X/files/project/ScriptX/";
// 定义白名单，白名单中的文件或文件夹不会被删除
const whiteList = [
    ".ScriptX.js"
];

// 函数：删除文件夹内的所有文件
function deleteFilesInFolder(folder) {
    if (files.exists(folder)) {
        let fileList = files.listDir(folder);
        for (let file of fileList) {
            let curPath = files.join(folder, file);
            let isInWhiteList = whiteList.some((item) => {
                // 检查当前路径是否在白名单中
                return curPath.endsWith(item);
            });
            if (isInWhiteList) {
                // 如果在白名单中，跳过不处理
                continue;
            }
            if (files.isDir(curPath)) {
                // 如果是子文件夹，递归删除子文件夹内的文件
                deleteFilesInFolder(curPath);
            } else {
                try {
                    files.remove(curPath);
                    console.log(`已删除文件: ${curPath}`);
                } catch (error) {
                    console.error(`删除文件 ${curPath} 时出错: `, error);
                }
            }
        }
    }
}

deleteFilesInFolder(folderPath);
console.log(`${folderPath} 内的所有非白名单文件已成功删除`);
toast("执行成功")

        break;
    default:
        break;
}

// 确保目录存在的函数，如果不存在则递归创建
function ensureDirExists(dirPath) {
    var dirs = dirPath.split("/");
    var currentDir = "";
    for (var k = 0; k < dirs.length; k++) {
        currentDir += dirs[k] + "/";
        if (dirs[k]!== "" &&!files.exists(currentDir)) {
            files.createDir(currentDir);
        }
    }
}
