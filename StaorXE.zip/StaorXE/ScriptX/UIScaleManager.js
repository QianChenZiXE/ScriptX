"ui";

/**
 * 强大的UI缩放管理器
 * 功能：
 * 1. 基于基准分辨率自动缩放
 * 2. 支持手动调整缩放比例
 * 3. 提供尺寸、边距、文字大小等缩放方法
 * 4. 支持横竖屏切换
 * 5. 与主题系统集成
 * 6. 提供调试信息
 */
const UIScaleManager = (function() {
    // 设计基准分辨率（1080x2460 竖屏）
    const BASE_WIDTH = 1080;
    const BASE_HEIGHT = 2460;
    
    // 存储键名
    const STORAGE_KEY = "ui_scale_manager";
    const SCALE_FACTOR_KEY = "scaleFactor";
    const ORIENTATION_KEY = "lastOrientation";
    
    // 创建存储
    const storage = storages.create(STORAGE_KEY);
    
    // 私有变量
    let _scaleFactor = storage.get(SCALE_FACTOR_KEY, 1.0);
    let _lastOrientation = storage.get(ORIENTATION_KEY, "portrait");
    let _themeAware = false;
    let _themeCallback = null;
    
    // 当前设备方向
    function getOrientation() {
        return device.width < device.height ? "portrait" : "landscape";
    }
    
    // 当前设备分辨率（考虑方向）
    function getDeviceWidth() {
        return getOrientation() === "portrait" 
            ? Math.min(device.width, device.height)
            : Math.max(device.width, device.height);
    }
    
    function getDeviceHeight() {
        return getOrientation() === "portrait" 
            ? Math.max(device.width, device.height)
            : Math.min(device.width, device.height);
    }
    
    // 计算基础缩放比例
    function getBaseScale() {
        const widthScale = getDeviceWidth() / BASE_WIDTH;
        const heightScale = getDeviceHeight() / BASE_HEIGHT;
        return Math.min(widthScale, heightScale);
    }
    
    // 计算最终缩放比例
    function getActualScale() {
        return getBaseScale() * _scaleFactor;
    }
    
    // 检查方向是否改变
    function checkOrientationChanged() {
        const currentOrientation = getOrientation();
        if (currentOrientation !== _lastOrientation) {
            _lastOrientation = currentOrientation;
            storage.put(ORIENTATION_KEY, currentOrientation);
            events.broadcast.emit("ui_orientation_changed", {
                orientation: currentOrientation,
                scale: getActualScale()
            });
            return true;
        }
        return false;
    }
    
    // 公开API
    return {
        /**
         * 启用主题感知模式
         * @param {function} callback 当主题变化时的回调函数
         */
        enableThemeAware(callback) {
            _themeAware = true;
            _themeCallback = callback;
            events.broadcast.on("theme_changed", () => {
                if (_themeCallback) _themeCallback();
            });
        },
        
        /**
         * 设置缩放系数
         * @param {number} factor 缩放系数 (0.5-1.5)
         */
        set scaleFactor(factor) {
            const newFactor = Math.max(0.5, Math.min(1.5, factor));
            if (newFactor !== _scaleFactor) {
                _scaleFactor = newFactor;
                storage.put(SCALE_FACTOR_KEY, _scaleFactor);
                
                events.broadcast.emit("ui_scale_changed", {
                    scale: getActualScale(),
                    factor: _scaleFactor,
                    orientation: getOrientation()
                });
            }
        },
        
        /**
         * 获取当前缩放系数
         * @return {number} 当前缩放系数
         */
        get scaleFactor() {
            return _scaleFactor;
        },
        
        /**
         * 获取当前实际缩放比例
         * @return {number} 实际缩放比例
         */
        get scale() {
            checkOrientationChanged();
            return getActualScale();
        },
        
        /**
         * 尺寸缩放
         * @param {number} originalSize 原始尺寸
         * @return {number} 缩放后的尺寸
         */
        size(originalSize) {
            return Math.round(originalSize * this.scale);
        },
        
        /**
         * 边距缩放
         * @param {...number} args 边距参数(1-4个)
         * @return {string|number} 缩放后的边距值
         */
        margin() {
            const args = Array.from(arguments);
            if (args.length === 1) {
                return this.size(args[0]);
            } else if (args.length === 2) {
                return this.size(args[0]) + " " + this.size(args[1]);
            } else if (args.length === 4) {
                return args.map(arg => this.size(arg)).join(" ");
            }
            return 0;
        },
        
        /**
         * 文字大小缩放（保证最小10px）
         * @param {number} originalSize 原始文字大小
         * @return {number} 缩放后的文字大小
         */
        textSize(originalSize) {
            return Math.max(this.size(originalSize), 10);
        },
        
        /**
         * 获取当前设备方向
         * @return {string} "portrait"或"landscape"
         */
        get orientation() {
            return getOrientation();
        },
        
        /**
         * 显示调试信息
         */
        logInfo() {
            console.log("===== UI缩放管理器信息 =====");
            console.log(`设计基准分辨率: ${BASE_WIDTH}x${BASE_HEIGHT}`);
            console.log(`设备分辨率: ${getDeviceWidth()}x${getDeviceHeight()}`);
            console.log(`设备方向: ${getOrientation()}`);
            console.log(`基础缩放比例: ${getBaseScale().toFixed(3)}`);
            console.log(`缩放系数: ${_scaleFactor.toFixed(2)}`);
            console.log(`实际缩放比例: ${getActualScale().toFixed(3)}`);
            console.log("==========================");
        },
        
        /**
         * 重置为默认缩放系数
         */
        reset() {
            this.scaleFactor = 1.0;
        },
        
        /**
         * 显示缩放调整对话框
         */
        showScaleDialog() {
            dialogs.input("缩放比例 (0.5-1.5)", _scaleFactor)
                .then(num => {
                    if (num === null) return;
                    const factor = parseFloat(num);
                    if (!isNaN(factor) && factor >= 0.5 && factor <= 1.5) {
                        this.scaleFactor = factor;
                    } else {
                        toast("请输入0.5到1.5之间的有效数字");
                    }
                });
        }
    };
})();

// 导出模块
module.exports = UIScaleManager;