var i = dialogs.select("垃圾清理", "1. 打印/目录", "2. 清理/工具");
switch(i){
case 0:
 
// 定义一个函数来遍历指定目录并打印所有文件夹
function listFolders(dirPath) {
    var dir = new java.io.File(dirPath);

    // 检查目录是否存在并且是一个目录
    if (dir.exists() && dir.isDirectory()) {
        // 获取目录下的所有文件和文件夹
        var items = dir.listFiles();

        if (items != null) {
            for (var i = 0; i < items.length; i++) {
                var item = items[i];

                // 检查是否是目录
                if (item.isDirectory()) {
                    console.log(item.getAbsolutePath());
                }
            }
        } else {
            console.error("无法读取目录内容: " + dirPath);
        }
    } else {
        console.error("指定的路径不是一个有效的目录: " + dirPath);
    }
}

// 开始遍历 /sdcard/ 目录
listFolders("/sdcard/");

    break;
case 1:
// Auto.js 静默清理脚本（无悬浮窗版）

// 配置选项
var config = {
    debug: true, // 设为true可显示详细日志
    delay: {
        min: 100, // 最小延迟(ms)
        max: 100 // 最大延迟(ms)
    }
};

// 白名单配置
var whitelist = [];

/**
 * 随机延迟（避免检测）
 */
function randomDelay() {
    if (!config.debug) {
        var delay = random(config.delay.min, config.delay.max);
        sleep(delay);
    }
}

/**
 * 显示简单的白名单管理界面
 */
function showWhitelistMenu() {
    while (true) {
        var options = [
            "1. 查看当前白名单",
            "2. 添加白名单路径",
            "3. 开始清理",
        ];
        
        var choice = dialogs.select("文件清理工具", options);
        randomDelay();
        
        switch (choice) {
            case 0: // 查看白名单
                var message = "当前白名单路径：\n";
                whitelist.forEach(function(path) {
                    message += "• " + path + "\n";
                });
                message += "\n示例路径格式：\n/sdcard/Download\n/sdcard/Music";
                dialogs.alert("白名单列表", message);
                break;
                
            case 1: // 添加白名单
                var input = dialogs.rawInput("添加白名单", "");
                if (input) {
                    input = input.trim();
                    if (!input.startsWith("/sdcard/")) {
                        input = "/sdcard/" + input.replace(/^\//, "");
                    }
                    
                    if (whitelist.indexOf(input) === -1) {
                        whitelist.push(input);
                        toast("已添加: " + input);
                    } else {
                        toast("路径已在白名单中");
                    }
                }
                randomDelay();
                break;
                
            case 2: // 开始清理
                startCleaning();
                return;
                
            case 3: // 退出
            default:
                exit();
                return;
        }
    }
}

/**
 * 检查路径是否在白名单中
 */
function isWhitelisted(path) {
    for (var i = 0; i < whitelist.length; i++) {
        if (path.indexOf(whitelist[i]) === 0) {
            return true;
        }
    }
    return false;
}

/**
 * 安全删除文件或目录
 */
function safeDelete(file) {
    try {
        if (isWhitelisted(file.getAbsolutePath())) {
            if (config.debug) console.log("跳过白名单: " + file.getPath());
            return;
        }

        if (file.isDirectory()) {
            var children = file.listFiles();
            if (children) {
                for (var i = 0; i < children.length; i++) {
                    safeDelete(children[i]);
                    randomDelay();
                }
            }
        }
        
        if (!file.delete()) {
            if (config.debug) console.warn("删除失败: " + file.getPath());
        } else {
            if (config.debug) console.log("已删除: " + file.getPath());
        }
        randomDelay();
    } catch (e) {
        if (config.debug) console.error("错误: " + file.getPath() + " - " + e);
    }
}

/**
 * 开始清理流程
 */
function startCleaning() {
    // 最终确认
    var confirmMsg = "即将清理 /sdcard/ 下所有非白名单文件！\n\n";
    confirmMsg += "白名单路径:\n";
    whitelist.forEach(function(path) {
        confirmMsg += "• " + path + "\n";
    });
    confirmMsg += "\n此操作不可恢复！确定继续吗？";
    
    if (!dialogs.confirm("危险操作确认", confirmMsg)) {
        toast("操作已取消");
        return;
    }

    // 目标目录
    var targetDir = new java.io.File("/sdcard/");
    
    if (!targetDir.exists()) {
        dialogs.alert("错误", "/sdcard/ 目录不存在！");
        return;
    }

    // 执行清理
    var children = targetDir.listFiles();
    if (children) {
        for (var i = 0; i < children.length; i++) {
            safeDelete(children[i]);
        }
    }
    
    toast("清理完成！");
    if (config.debug) {
        //console.log("===== 清理操作已完成 =====");
    }
}

// 脚本入口
showWhitelistMenu();

    break;
}