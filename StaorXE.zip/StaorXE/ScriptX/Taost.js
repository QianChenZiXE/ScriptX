// 存储文件路径
var storagePath = "/data/user/0/S.cript.X/files/project/firstRun.txt";

// 检查是否是第一次运行
var isFirstRun = !files.exists(storagePath);

if (isFirstRun) {
    // 如果是第一次运行，显示通告框
    alert("权限需求", 
          "使用完整功能需要以下权限：\n\n" +
          "1. 读写剪切板\n" +
          "2. 获取应用列表\n" +
          "3. 后台弹出界面\n" +
          "4. 悬浮窗权限\n\n" +
          "请确保已授予所有必要权限");
    
    // 创建标记文件
    files.createWithDirs(storagePath);
    files.write(storagePath, "已运行过");
}

// 5秒后退出（示例，实际使用时可以移除）
setTimeout(function() {
    exit();
}, 5000);