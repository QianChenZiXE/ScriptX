 // 改进后的代码
var whiteList = ["main.js"];  // 白名单
var blackList = ["Floaty.js","Base64.js","Character.js","CopyDir.js","create.js","delete.js","Dircache.js","Fitter.js","Launchapp.js","Print.js","Panel.js","Calculator.js"];  // 黑名单

// 使用更安全的文件名提取方法
function getFileName(path) {
    if (!path) return '';
    // 处理各种可能的路径分隔符
    return path.replace(/^.*[\\\/]/, '');
}

engines.all().forEach(function(engine) {
    try {
        var scriptSource = engine.getSource();
        var scriptFileName = scriptSource ? scriptSource.toString() : '';
        var fileNameOnly = getFileName(scriptFileName);
        
        console.log("检查脚本: " + fileNameOnly);

        if (whiteList.includes(fileNameOnly)) {
            console.log("脚本在白名单中，跳过: " + fileNameOnly);
            return;  // 继续下一个脚本
        }

        if (blackList.includes(fileNameOnly)) {
            console.log("停止黑名单脚本: " + fileNameOnly);
            try {
                engine.forceStop();
                console.log("成功停止: " + fileNameOnly);
            } catch (e) {
                console.error("停止脚本失败: " + fileNameOnly, e);
            }
            return;
        }

        console.log("脚本未在名单中，保留: " + fileNameOnly);
    } catch (e) {
        console.error("处理脚本时出错: ", e);
    }
});

console.log("脚本检查完成");
exit();