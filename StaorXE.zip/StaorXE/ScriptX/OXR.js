/* 加密工具完整修复版 v1.5 */
/* 已修复所有括号匹配问题 */

// ======================== 主界面 ========================
var selectedAlgorithm = dialogs.select("请选择加密算法", [
    "1. Stream Cipher",
    "2. Stream Cipher⁺", 
    "3. Salted XOR-Circular"
]);

// ======================== 通用函数 ========================
function showResult(title, content) {
    log("===== " + title + " =====");
    log(content);
    setClip(content);
    dialogs.alert(title, "结果已复制到剪贴板\n\n" + content);
}

function handleError(error) {
    console.error(error);
    dialogs.alert("错误", error.message);
}

// ======================== 算法实现 ========================

// 算法1: 基础流加密
function basicStreamCipher() {
    function encrypt(text, key) {
        let result = "";
        for (let i = 0; i < text.length; i++) {
            result += String.fromCharCode(
                (text.charCodeAt(i) + key.charCodeAt(i % key.length)) % 65536
            );
        }
        return result;
    }

    function decrypt(text, key) {
        let result = "";
        for (let i = 0; i < text.length; i++) {
            result += String.fromCharCode(
                (text.charCodeAt(i) - key.charCodeAt(i % key.length) + 65536) % 65536
            );
        }
        return result;
    }

    executeAlgorithm("Stream Cipher", encrypt, decrypt);
}

// 算法2: 增强流加密
function enhancedStreamCipher() {
    function expandKey(key) {
        let expandedKey = [];
        for (let i = 0; i < key.length; i++) {
            let seed = key.charCodeAt(i);
            for (let j = 0; j < 4; j++) {
                seed = (seed * 16807) % 2147483647;
                expandedKey.push(seed % 256);
            }
        }
        return expandedKey;
    }

    function encrypt(text, key) {
        const expandedKey = expandKey(key);
        return Array.from(text).map(function(c, index) {
            let code = c.charCodeAt(0);
            code ^= expandedKey[index % expandedKey.length];
            code = ((code << 3) | (code >>> 5)) & 0xFF;
            code = (code + expandedKey[(index + 7) % expandedKey.length]) % 256;
            return String.fromCharCode(code);
        }).join('');
    }

    function decrypt(text, key) {
        const expandedKey = expandKey(key);
        return Array.from(text).map(function(c, index) {
            let code = c.charCodeAt(0);
            code = (code - expandedKey[(index + 7) % expandedKey.length] + 256) % 256;
            code = ((code >>> 3) | (code << 5)) & 0xFF;
            code ^= expandedKey[index % expandedKey.length];
            return String.fromCharCode(code);
        }).join('');
    }

    executeAlgorithm("Stream Cipher⁺", encrypt, decrypt);
}

// 算法3: 加盐循环加密（无盐值位数限制）
function saltedCircularCipher() {
    function generateSalt() {
        const chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz';
        let salt = '';
        const length = Math.floor(Math.random() * 57) + 8;
        for (let i = 0; i < length; i++) {
            salt += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return salt;
    }

    function expandKey(key, salt) {
        let expandedKey = [];
        for (let i = 0; i < key.length; i++) {
            let seed = key.charCodeAt(i) * (i + 1);
            for (let j = 0; j < 8; j++) {
                seed = (seed * 16807 + (salt.charCodeAt(j % salt.length) || 0)) % 2147483647;
                expandedKey.push(seed % 256);
            }
        }
        const iv = expandedKey[0] ^ expandedKey[expandedKey.length - 1];
        expandedKey.unshift(iv);
        return expandedKey;
    }

    function encrypt(text, key, customSalt) {
        const salt = customSalt || generateSalt();
        const expandedKey = expandKey(key, salt);

        const encryptedData = Array.from(text).map(function(c, index) {
            let code = c.charCodeAt(0);
            code ^= expandedKey[(index * 2) % expandedKey.length];
            code = ((code << 4) | (code >>> 4)) & 0xFF;
            code = (code + expandedKey[(index + 11) % expandedKey.length]) % 256;
            code ^= expandedKey[(index * 3 + 5) % expandedKey.length];
            return String.fromCharCode(code);
        }).join('');

        return {
            full: salt + '|' + encryptedData,
            encrypted: encryptedData,
            salt: salt
        };
    }

    function decrypt(text, key) {
        const splitIndex = text.indexOf('|');
        if (splitIndex === -1) throw new Error("无效的加密格式（缺少盐值分隔符'|'）");
        
        const salt = text.substring(0, splitIndex);
        const encryptedData = text.substring(splitIndex + 1);
        const expandedKey = expandKey(key, salt);

        return Array.from(encryptedData).map(function(c, index) {
            let code = c.charCodeAt(0);
            code ^= expandedKey[(index * 3 + 5) % expandedKey.length];
            code = (code - expandedKey[(index + 11) % expandedKey.length] + 256) % 256;
            code = ((code >>> 4) | (code << 4)) & 0xFF;
            code ^= expandedKey[(index * 2) % expandedKey.length];
            return String.fromCharCode(code);
        }).join('');
    }

    executeAlgorithm("Salted XOR-Circular", encrypt, decrypt, true);
}

// ======================== 执行逻辑 ========================
function executeAlgorithm(algorithmName, encryptFunc, decryptFunc, needSalt) {
    try {
        const input = dialogs.rawInput("请输入要处理的内容：");
        if (!input) return;
        
        const key = dialogs.rawInput("请输入密钥：");
        if (!key) throw new Error("密钥不能为空");

        const mode = dialogs.select("请选择模式", ["加密", "解密"]);
        
        let result;
        if (mode === 0) {
            if (needSalt) {
                const useCustomSalt = dialogs.confirm("盐值设置", "是否使用自定义盐值？\n（取消将自动生成随机盐值）");
                const customSalt = useCustomSalt ? dialogs.rawInput("请输入自定义盐值（任意长度）：") : null;
                result = encryptFunc(input, key, customSalt);
                showResult(algorithmName + "加密结果", result.full);
            } else {
                result = encryptFunc(input, key);
                showResult(algorithmName + "加密结果", result);
            }
        } else {
            result = decryptFunc(input, key);
            showResult(algorithmName + "解密结果", result);
        }

    } catch (e) {
        handleError(e);
    }
}

// ======================== 主程序 ========================
if (selectedAlgorithm >= 0) {
    switch (selectedAlgorithm) {
        case 0:
            basicStreamCipher();
            break;
        case 1:
            enhancedStreamCipher();
            break;
        case 2:
            saltedCircularCipher();
            break;
    }
} else {
    toast("操作已取消");
}
