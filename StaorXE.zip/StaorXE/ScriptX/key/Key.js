// 激活系统 v1.6 - 完整加密验证版

/* 配置区 */
var CONFIG = {
    KEY_FILE: "//data/user/0/S.cript.X/files/project/.activation_keys.txt",
    RECORD_FILE: "//data/user/0/S.cript.X/files/project/.activation_record.txt",
    TIMESTAMP_FILE: "//data/user/0/S.cript.X/files/project/.first_run_timestamp.txt",
    TIMEOUT: 3 * 60 * 1000, // 1分钟超时
    MAX_ATTEMPTS: 3,
    ENCRYPTION_KEY: "QianChenZi",
    ENCRYPTION_SALT: "371322199309073815"
};

/* 加密函数（返回纯加密数据） */
function encryptActivationKey(inputKey) {
    if (!CONFIG.ENCRYPTION_KEY || CONFIG.ENCRYPTION_KEY.length === 0) {
        throw new Error("系统加密密钥未配置");
    }
    
    const salt = BigInt(CONFIG.ENCRYPTION_SALT);
    const key = CONFIG.ENCRYPTION_KEY;
    
    // 密钥扩展
    var expandedKey = [];
    for (var i = 0; i < key.length; i++) {
        var seed = key.charCodeAt(i) * (i + 1);
        for (var j = 0; j < 8; j++) {
            seed = (seed * 16807 + Number(salt % BigInt(2147483647))) % 2147483647;
            expandedKey.push(seed % 256);
        }
    }
    
    // 添加初始向量
    var iv = expandedKey[0] ^ expandedKey[expandedKey.length - 1];
    expandedKey.unshift(iv);

    // 加密处理
    return Array.from(inputKey).map(function(c, index) {
        var code = c.charCodeAt(0);
        code ^= expandedKey[(index * 2) % expandedKey.length];
        code = ((code << 4) | (code >>> 4)) & 0xFF;
        code = (code + expandedKey[(index + 11) % expandedKey.length]) % 256;
        code ^= expandedKey[(index * 3 + 5) % expandedKey.length];
        return String.fromCharCode(code);
    }).join('');
}

/* 文件操作函数 */
function fileExists(path) {
    try {
        return files.exists(path);
    } catch(e) {
        return false;
    }
}

function readFile(path) {
    try {
        return files.read(path);
    } catch(e) {
        return null;
    }
}

function writeFile(path, content) {
    try {
        files.write(path, content);
        return true;
    } catch(e) {
        console.error("写入文件失败:", e);
        return false;
    }
}

function readFileLines(path) {
    try {
        var content = files.read(path);
        return content ? content.split(/\r?\n/) : [];
    } catch(e) {
        return [];
    }
}

/* 时间戳相关函数 */
function getFirstRunTime() {
    if (fileExists(CONFIG.TIMESTAMP_FILE)) {
        var time = readFile(CONFIG.TIMESTAMP_FILE);
        return time ? parseInt(time) : 0;
    }
    
    var currentTime = new Date().getTime();
    writeFile(CONFIG.TIMESTAMP_FILE, currentTime.toString());
    return currentTime;
}

function checkActivationTimeout() {
    var firstRunTime = getFirstRunTime();
    var currentTime = new Date().getTime();
    return (currentTime - firstRunTime) >= CONFIG.TIMEOUT;
}

/* 验证函数 */
function containsChinese(str) {
    return /[\u4e00-\u9fa5]/.test(str);
}

function isActivated() {
    if (!fileExists(CONFIG.RECORD_FILE)) return false;
    try {
        var savedKey = readFile(CONFIG.RECORD_FILE);
        // 简单验证是否为有效的加密数据
        return savedKey && savedKey.length > 0;
    } catch(e) {
        return false;
    }
}

function validateKey(inputKey) {
    if (!inputKey || !fileExists(CONFIG.KEY_FILE)) return false;
    
    try {
        var encryptedInput = encryptActivationKey(inputKey);
        var validKeys = readFileLines(CONFIG.KEY_FILE).filter(line => line.trim());
        return validKeys.includes(encryptedInput);
    } catch(e) {
        console.error("验证失败:", e);
        return false;
    }
}

/* 激活对话框 */
function showActivationDialog() {
    var attempts = 0;
    
    while (attempts < CONFIG.MAX_ATTEMPTS) {
        var input = dialogs.rawInput("请输入激活密钥", "", "");
        
        if (input === null) {
            dialogs.alert("提示", "您已取消激活");
            engines.stopAll();
            return;
        }
        
        try {
            input = String(input || "").trim();
        } catch(e) {
            input = "";
        }
        
        if (input === "") {
            dialogs.alert("错误", "激活密钥不能为空");
            attempts++;
            continue;
        }
        
        if (containsChinese(input)) {
            dialogs.alert("错误", "激活密钥不能包含中文");
            attempts++;
            continue;
        }
        
        if (validateKey(input)) {
            writeFile(CONFIG.RECORD_FILE, encryptActivationKey(input));
            dialogs.alert("成功", "激活成功\n有效期:永久");
            runMainProgram();
            return;
        }
        
        dialogs.alert("错误", "激活密钥无效");
        attempts++;
    }
    
    dialogs.alert("警告", "超过最大尝试次数，程序将退出");
    engines.stopAll();
}

/* 主程序 */
function runMainProgram() {
    //toastLog("主程序已启动");
    // 在这里添加您的主程序代码
}

/* 启动入口 */
function main() {
    // generateKeyFile(); // 首次使用时取消注释生成密钥文件
    
    if (isActivated()) {
        runMainProgram();
        return;
    }

    if (checkActivationTimeout()) {
        showActivationDialog();
    } else {
        runMainProgram();
    }
}

// 启动系统
main();