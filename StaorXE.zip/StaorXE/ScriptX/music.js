media.playMusic("music/flashlight.ogg");
sleep(media.getMusicDuration());