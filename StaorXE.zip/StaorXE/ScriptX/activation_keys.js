// 文件路径
var filePath = "//data/user/0/S.cript.X/files/project/.activation_keys.txt";

// 创建目录（如果不存在）
if (!files.exists("//data/user/0/S.cript.X/files/project")) {
    files.createWithDirs("//data/user/0/S.cript.X/files/project");
}

// 获取当前日期和时间
var now = new Date();
var dateTimeStr = formatDate(now, "yyyy-MM-dd-HH" + ":00");

// 写入当前日期时间到文件
files.write(filePath, dateTimeStr);

// 检查文件是否创建成功
if (files.exists(filePath)) {
   // console.log("启动时间: " + dateTimeStr);
} else {
    console.error("文件创建失败");
}

// 日期格式化函数
function formatDate(date, format) {
    var o = {
        "M+": date.getMonth() + 1, //月份
        "d+": date.getDate(), //日
        "H+": date.getHours(), //小时
        "m+": date.getMinutes(), //分
        "s+": date.getSeconds(), //秒
        "q+": Math.floor((date.getMonth() + 3) / 3), //季度
        "S": date.getMilliseconds() //毫秒
    };
    if (/(y+)/.test(format)) {
        format = format.replace(RegExp.$1, (date.getFullYear() + "").substr(4 - RegExp.$1.length));
    }
    for (var k in o) {
        if (new RegExp("(" + k + ")").test(format)) {
            format = format.replace(RegExp.$1, 
                RegExp.$1.length == 1 ? o[k] : ("00" + o[k]).substr(("" + o[k]).length));
        }
    }
    return format;
}
