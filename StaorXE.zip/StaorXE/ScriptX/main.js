"ui";
// 引入共享缩放管理器
const ResolutionAdapter = require("./UIScaleManager");

/*=====================
 * 主题管理器
 *=====================*/
const ThemeManager = {
    themeIndex: 0,
    themes: [
        { // 主题1 - 翡翠绿
            name: "AutoJs",
            color: "#009688",
            images: {
                logo: "file://UI/image/ScriptX/ScriptX.png",
                button: "file://UI/image/Button/button.png",
                log: "file://UI/image/PNG/Scripc.png",
                theme: "file://UI/image/PNG/input.png"
            },
            contentBg: "#F5F5F5",
            buttonEvents: {
                mainBtn: "Character/CharacterB.js",
                leftBtn: "Print.js",
                rightBtn: "Launchapp.js",
                leftSmallBtn: "OXR.js",
                centerBtn: "Dircache.js",
                rightSmallBtn: "CopyDir.js",
                Exit: ["music.js", "Exit.js"]
            },
            logoEvents: {
                1: "Describe.js",
                2: "Panel/PanelB.js",
                3: "Calculator/CalculatorB.js",
                4: () => {
                    ThemeManager.nextTheme();
                    renderUI();
                },
                5: "Floaty.js",
                6: "activation_record.js",
                7: "Compass.js",
                10: () => {
                    ui.scaleControl.click();
                }
            }
        },
    
        { // 主题2 - 海洋蓝
            name: "AutoJs",
            color: "#0E7D81",
            images: {
                logo: "file://UI/image/ScriptX/ScriptX².png",
                button: "file://UI/image/Button/button².png",
                log: "file://UI/image/PNG/Scripc.png",
                theme: "file://UI/image/PNG/input.png"
            },
            contentBg: "#FFFFFF",
            buttonEvents: {
                mainBtn: "Character/CharacterA.js",
                leftBtn: "Print.js",
                rightBtn: "Launchapp.js",
                leftSmallBtn: "OXR.js",
                centerBtn: "Dircache.js",
                rightSmallBtn: "CopyDir.js",
                Exit: ["music.js", "Exit.js"]
            },
            logoEvents: {
                1: "Describe.js",
                2: "Panel/PanelA.js",
                3: "Calculator/CalculatorA.js",
                4: () => {
                    ThemeManager.nextTheme();
                    renderUI();
                },
                5: "Floaty.js",
            }
        },

        { // 主题3 - 岩石灰
            name: "AutoJs",
            color: "#5D5D5D",
            images: {
                logo: "file://UI/image/ScriptX/ScriptX⁵.png",
                button: "file://UI/image/Button/button⁵.png",
                log: "file://UI/image/PNG/Scripc.png",
                theme: "file://UI/image/PNG/input.png"
            },
            contentBg: "#EEEEEE",
            buttonEvents: {
                mainBtn: "Character/CharacterC.js",
                leftBtn: "Print.js",
                rightBtn: "Launchapp.js",
                leftSmallBtn: "OXR.js",
                centerBtn: "Dircache.js",
                rightSmallBtn: "CopyDir.js",
                Exit: ["music.js", "Exit.js"]
            },
            logoEvents: {
                1: "Describe.js",
                2: "Panel/PanelC.js",
                3: "Calculator/CalculatorC.js",
                4: () => {
                    ThemeManager.nextTheme();
                    renderUI();
                },
                5: "Floaty.js"
            }
        }
    ],
    
    init() {
        const themeStorage = storages.create("app_theme");
        this.themeIndex = Math.min(themeStorage.get("index", 0), this.themes.length - 1);
        this.lastTheme = themeStorage.get("lastTheme", {});
    },
    
    get currentTheme() {
        return this.themes[this.themeIndex];
    },
    
    nextTheme() {
        this.saveThemeState();
        this.themeIndex = (this.themeIndex + 1) % this.themes.length;
        storages.create("app_theme").put("index", this.themeIndex);
        return this.currentTheme;
    },
    
    saveThemeState() {
        const state = {
            timestamp: new Date().getTime(),
            themeName: this.currentTheme.name
        };
        storages.create("app_theme").put("lastTheme", state);
    },
    
    getTextColor(hexColor) {
        const hex = hexColor.replace("#", "");
        const r = parseInt(hex.substr(0, 2), 16);
        const g = parseInt(hex.substr(2, 2), 16);
        const b = parseInt(hex.substr(4, 2), 16);
        return (r * 299 + g * 587 + b * 114) / 1000 > 128 ? "#FFFFFF" : "#606060";
    },
    
    applyStatusBarStyle() {
        ui.statusBarColor(this.currentTheme.color);
        if (device.sdkInt >= 23) {
            const decorView = activity.getWindow().getDecorView();
            const flags = decorView.getSystemUiVisibility();
            const newFlags = this.getTextColor(this.currentTheme.color) === "#000000"
                ? flags | android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                : flags & ~android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
            decorView.setSystemUiVisibility(newFlags);
        }
    }
};

ThemeManager.init();

/*=====================
 * 自适应UI渲染核心
 *=====================*/
function renderUI() {
    const theme = ThemeManager.currentTheme;
    const textColor = ThemeManager.getTextColor(theme.color);
    
    ThemeManager.applyStatusBarStyle();
    
    ui.layout(
        <frame>
            <scroll bg={theme.color}>
                <vertical>
                    <!-- 顶部控制栏 -->
                    <horizontal gravity="right" marginTop={ResolutionAdapter.margin(10)} marginRight={ResolutionAdapter.margin(20)}>
                        <text
                            bg={theme.images.log}
                            id="log"
                            w={ResolutionAdapter.size(28)}
                            h={ResolutionAdapter.size(28)}
                            marginRight={ResolutionAdapter.margin(10)}
                            gravity="center"
                        />
                         <text
                            bg={theme.images.theme}
                            id="scaleControl"
                            w={ResolutionAdapter.size(0)}
                            h={ResolutionAdapter.size(0)}
                            gravity="center"
                            marginRight={ResolutionAdapter.margin(0)}
                        />
                    </horizontal>

                    <!-- 主标题 -->
                    <text
                        gravity="center"
                        textSize={ResolutionAdapter.textSize(30)}
                        textColor="#FFFFFF"
                        textStyle="bold"
                        text="Script X"
                        marginTop="-10"
                    />

                    <!-- 主内容区 -->
                    <vertical marginTop={ResolutionAdapter.margin(30)} bg={theme.contentBg} h={ResolutionAdapter.size(700)} w="*">
                        <View h={ResolutionAdapter.size(2)} bg="#FF898989"/>
                        <!-- 应用LOGO -->
                        <img
                            marginTop={ResolutionAdapter.margin(-20)}
                            layout_gravity="center"
                            src={theme.images.logo}
                            w={ResolutionAdapter.size(200)}
                            h={ResolutionAdapter.size(200)}
                            id="logo"
                        />
                        <text 
                            marginTop={ResolutionAdapter.margin(-40)}
                            gravity="center" 
                            textColor={textColor}
                            textStyle="bold" 
                            textSize={ResolutionAdapter.textSize(30)}
                            text={theme.name} 
                        />
                        <text 
                            marginTop="10"
                            gravity="center" 
                            textColor="#FF898989"
                            textStyle="bold" 
                            textSize={ResolutionAdapter.textSize(15)}
                            text="基于 JavaScript⁵ 引擎" 
                        />
                    
                        <!-- 功能按钮区 -->
                        <vertical marginTop={ResolutionAdapter.margin(40)}>
                            <!-- 主按钮 -->
                            <button
                                w={ResolutionAdapter.size(260)}
                                id="mainBtn"
                                layout_gravity="center"
                                textStyle="bold"
                                backgroundTint={theme.color}
                                textSize={ResolutionAdapter.textSize(15)}
                                textColor="#ffffff"
                                text="特殊 ⌨ 字符"
                            />

                            <!-- 双按钮 -->
                            <horizontal gravity="center" marginTop={ResolutionAdapter.margin(10)}>
                                <button
                                    w={ResolutionAdapter.size(130)}
                                    id="leftBtn"
                                    backgroundTint={theme.color}
                                    textSize={ResolutionAdapter.textSize(15)}
                                    textColor="#ffffff"
                                    text="应用 ⎋ 打印"
                                />
                                <button
                                    w={ResolutionAdapter.size(130)}
                                    id="rightBtn"
                                    backgroundTint={theme.color}
                                    textSize={ResolutionAdapter.textSize(15)}
                                    textColor="#ffffff"
                                    text="应用 ☍ 启动"
                                />
                            </horizontal>

                            <!-- 三按钮 -->
                            <horizontal gravity="center" marginTop={ResolutionAdapter.margin(10)}>
                                <button
                                    w={ResolutionAdapter.size(70)}
                                    id="leftSmallBtn"
                                    backgroundTint={theme.color}
                                    textSize={ResolutionAdapter.textSize(15)}
                                    textColor="#ffffff"
                                    text="➲"
                                />
                                <button
                                    w={ResolutionAdapter.size(120)}
                                    id="centerBtn"
                                    backgroundTint={theme.color}
                                    textSize={ResolutionAdapter.textSize(15)}
                                    textColor="#ffffff"
                                    text="缓存 𖥂 垃圾"
                                />
                                <button
                                    w={ResolutionAdapter.size(70)}
                                    id="rightSmallBtn"
                                    backgroundTint={theme.color}
                                    textSize={ResolutionAdapter.textSize(15)}
                                    textColor="#ffffff"
                                    text="❖"
                                />
                            </horizontal>
                        </vertical>

                        <!-- 底部信息 -->
                        <vertical marginTop={ResolutionAdapter.margin(40)}>
                            <text
                                textSize={ResolutionAdapter.textSize(15)}
                                gravity="center"
                                textColor="#FF898989"
                                text="千塵の子"
                            />
                            <text
                                textSize={ResolutionAdapter.textSize(15)}
                                gravity="center"
                                textColor="#FF898989"
                                text="浮生万绪 恍若千塵"
                            />
                            <text
                                textSize={ResolutionAdapter.textSize(13)}
                                gravity="center"
                                textColor="#FF898989"
                                text="v 6.3.3 betaᵉˢ⁵⁺⁺"
                            />
                        </vertical>
                       
                        <!-- 退出按钮 -->
                        <button
                            h={ResolutionAdapter.size(60)}
                            w={ResolutionAdapter.size(60)}
                            marginTop={ResolutionAdapter.margin(30)}
                            layout_gravity="right"
                            marginLeft={ResolutionAdapter.margin(30)}
                            marginRight={ResolutionAdapter.margin(30)}
                            bg={theme.images.button}
                            id="Exit"
                        />
                        <View h={ResolutionAdapter.size(0)}/>
                    </vertical>
                    <View h={ResolutionAdapter.size(2)} bg="#FF898989"/>
                    <View h={ResolutionAdapter.size(40)} bg={theme.color}/>
                </vertical>
            </scroll>
        </frame>
    );
    
    bindEvents();
}

// 禁止横屏
ui.emitter.on("config_changed", function(newConfig) {
    if (newConfig.orientation !== android.content.res.Configuration.ORIENTATION_PORTRAIT) {
        // 强制设置为竖屏
        activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }
});
// 初始设置为竖屏
activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
/*=====================
 * 事件绑定
 *=====================*/
function bindEvents() {
    const theme = ThemeManager.currentTheme;
    
    const launchScript = (script) => {
        device.vibrate(30);
        if (Array.isArray(script)) {
            script.forEach(s => engines.execScriptFile(s));
        } else if (typeof script === 'function') {
            script();
        } else {
            engines.execScriptFile(script);
        }
    };
    
    // 日志按钮
    ui.log.click(() => app.startActivity("console"));
    
    // 主功能按钮
    ui.mainBtn.click(() => launchScript(theme.buttonEvents.mainBtn));
    ui.leftBtn.click(() => launchScript(theme.buttonEvents.leftBtn));
    ui.rightBtn.click(() => launchScript(theme.buttonEvents.rightBtn));
    ui.leftSmallBtn.click(() => launchScript(theme.buttonEvents.leftSmallBtn));
    ui.centerBtn.click(() => launchScript(theme.buttonEvents.centerBtn));
    ui.rightSmallBtn.click(() => launchScript(theme.buttonEvents.rightSmallBtn));
    ui.Exit.click(() => launchScript(theme.buttonEvents.Exit));
    
    // 缩放控制按钮
    ui.scaleControl.click(() => {
        dialogs.input("缩放比例 (0.5-1.5)", ResolutionAdapter.scaleFactor)
            .then(num => {
                if (num === null) return; // 用户点击取消
                const factor = parseFloat(num);
                if (!isNaN(factor) && factor >= 0.5 && factor <= 1.5) {
                    ResolutionAdapter.scaleFactor = factor;
                    renderUI(); // 重新渲染UI
                } else {
                    toast("请输入0.5到1.5之间的有效数字");
                }
            });
    });
    
    // LOGO多点触控
    let logoClickCount = 0;
    let lastClickTime = 0;
    ui.logo.click(() => {
        device.vibrate(30);
        const now = Date.now();
        if (now - lastClickTime > 500) logoClickCount = 0;
        logoClickCount++;
        lastClickTime = now;
        
        setTimeout(() => {
            if (Date.now() - lastClickTime >= 500) {
                const action = theme.logoEvents[logoClickCount];
                if (action) launchScript(action);
                logoClickCount = 0;
            }
        }, 500);
    });
}

/*=====================
 * 初始化执行
 *=====================*/
// 监听缩放变化事件
/*events.broadcast.on("ui_scale_changed", (data) => {
    toastLog(`UI缩放比例已更新: ${Math.rou/*nd(data.factor * 100)}%`);
});*/

// 初始渲染
renderUI();
//ResolutionAdapter.logInfo();

// 启动必要服务
engines.execScriptFile("activation_keys.js");
engines.execScriptFile("Key.js");
engines.execScriptFile("Taost.js");