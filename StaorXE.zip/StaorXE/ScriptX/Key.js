// 激活系统 v1.6 - 无加密版本

/* 配置区 */
var CONFIG = {
    KEY_FILE: "//data/user/0/S.cript.X/files/project/.activation_keys.txt",
    RECORD_FILE: "//data/user/0/S.cript.X/files/project/.activation_record.txt",
    TIMESTAMP_FILE: "//data/user/0/S.cript.X/files/project/.first_run_timestamp.txt",
    TIMEOUT: 3 * 60 * 1000, // 1分钟超时
    MAX_ATTEMPTS: 3,
};

/* 文件操作函数 */
function fileExists(path) {
    try {
        return files.exists(path);
    } catch(e) {
        return false;
    }
}

function readFile(path) {
    try {
        return files.read(path);
    } catch(e) {
        return null;
    }
}

function writeFile(path, content) {
    try {
        files.write(path, content);
        return true;
    } catch(e) {
        console.error("写入文件失败:", e);
        return false;
    }
}

function readFileLines(path) {
    try {
        var content = files.read(path);
        return content ? content.split(/\r?\n/) : [];
    } catch(e) {
        return [];
    }
}

/* 时间戳相关函数 */
function getFirstRunTime() {
    if (fileExists(CONFIG.TIMESTAMP_FILE)) {
        var time = readFile(CONFIG.TIMESTAMP_FILE);
        return time ? parseInt(time) : 0;
    }
    
    var currentTime = new Date().getTime();
    writeFile(CONFIG.TIMESTAMP_FILE, currentTime.toString());
    return currentTime;
}

function checkActivationTimeout() {
    var firstRunTime = getFirstRunTime();
    var currentTime = new Date().getTime();
    return (currentTime - firstRunTime) >= CONFIG.TIMEOUT;
}

/* 验证函数 */
function containsChinese(str) {
    return /[\u4e00-\u9fa5]/.test(str);
}

function isActivated() {
    if (!fileExists(CONFIG.RECORD_FILE)) return false;
    try {
        var savedKey = readFile(CONFIG.RECORD_FILE);
        // 简单验证是否为有效数据
        return savedKey && savedKey.length > 0;
    } catch(e) {
        return false;
    }
}

function validateKey(inputKey) {
    if (!inputKey || !fileExists(CONFIG.KEY_FILE)) return false;
    
    try {
        var validKeys = readFileLines(CONFIG.KEY_FILE).filter(line => line.trim());
        return validKeys.includes(inputKey);
    } catch(e) {
        console.error("验证失败:", e);
        return false;
    }
}

/* 激活对话框 */
function showActivationDialog() {
    var attempts = 0;
    
    while (attempts < CONFIG.MAX_ATTEMPTS) {
        var input = dialogs.rawInput("请输入激活密钥", "", "");
        
        if (input === null) {
            dialogs.alert("提示", "您已取消激活");
            engines.stopAll();
            return;
        }
        
        try {
            input = String(input || "").trim();
        } catch(e) {
            input = "";
        }
        
        if (input === "") {
            dialogs.alert("错误", "激活密钥不能为空");
            attempts++;
            continue;
        }
        
        if (containsChinese(input)) {
            dialogs.alert("错误", "激活密钥不能包含中文");
            attempts++;
            continue;
        }
        
        if (validateKey(input)) {
            writeFile(CONFIG.RECORD_FILE, input);
            dialogs.alert("成功", "激活成功\n有效期:永久");
            runMainProgram();
            return;
        }
        
        dialogs.alert("错误", "激活密钥无效");
        attempts++;
    }
    
    dialogs.alert("警告", "超过最大尝试次数，程序将退出");
    engines.stopAll();
}

/* 主程序 */
function runMainProgram() {
    //toastLog("主程序已启动");
    // 在这里添加您的主程序代码
}

/* 启动入口 */
function main() {
    // generateKeyFile(); // 首次使用时取消注释生成密钥文件
    
    if (isActivated()) {
        runMainProgram();
        return;
    }

    if (checkActivationTimeout()) {
        showActivationDialog();
    } else {
        runMainProgram();
    }
}

// 启动系统
main();