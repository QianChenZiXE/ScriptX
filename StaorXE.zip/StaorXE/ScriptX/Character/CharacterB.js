"ui";

// 引入UIScaleManager模块
const UIScaleManager = require("./UIScaleManager");

ui.statusBarColor("#009688");
ui.layout(
    <frame bg="#009688">
        <vertical>
            <!-- 标题区 -->
            <vertical>
                <View h={UIScaleManager.size(30)} bg="#009688"/>
                <text 
                    gravity="center"
                    textSize={UIScaleManager.textSize(30)}
                    textColor="#ffffff" 
                    textStyle="bold" 
                    text="特殊符号"
                />
                <View h={UIScaleManager.size(30)} bg="#009688"/>
            </vertical>
            
            <!-- 可滑动内容区 -->
            <scroll 
                id="scrollView"
                overScrollMode="ifContentScrolls" 
                fillViewport="true"
                scrollbarStyle="outsideOverlay"
                fadingEdgeLength={UIScaleManager.size(20)}
                verticalScrollBarEnabled="true"
                horizontalScrollBarEnabled="false"
                nestedScrollingEnabled="true">
                <vertical marginTop="0" bg="#ffffff" w="*" padding="0">
                    <!-- 第1行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol1" text="𖣔" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol2" text="𖤓" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol3" text="✇" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol4" text="𖥠" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol5" text="߷" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol6" text="⎋" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol7" text="☢" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第2行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol8" text="☣" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(28)} id="symbol9" text="⏱︎" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(28)} id="symbol10" text="⏲︎" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol11" text="☉" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol12" text="✧" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol13" text="✡" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol14" text="✮" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第3行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol15" text="⛨" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol16" text="⚙︎" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol17" text="⚛︎" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol18" text="⚕︎" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol19" text="⛛" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol20" text="⚉" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol21" text="◉" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第4行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol22" text="࿊" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol23" text="⦾" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol24" text="𖥕" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol25" text="☪" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol26" text="𖡼" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol27" text="𖥚" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol28" text="⍟" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第5行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol29" text="֍" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol30" text="𑁍" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol31" text="𖠇" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol32" text="➲" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol33" text="▣" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol34" text="◬" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol35" text="⊖" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第6行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol36" text="⊛" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol37" text="𖣠" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol38" text="𖥞" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol39" text="≜" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol40" text="✺" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol41" text="༜" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol42" text="𖥂" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第7行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol43" text="𖣓" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol44" text="⚆" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol45" text="⛶" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol46" text="♻︎" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol47" text="❂" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol48" text="◈" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol49" text="✿" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第8行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(30)} id="symbol50" text="⌖" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol51" text="∅" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol52" text="❖" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol53" text="✙" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol54" text="☍" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol55" text="₪" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol56" text="ↈ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第9行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol57" text="❏" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol58" text="※" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol59" text="⸙" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol60" text="এ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol61" text="๑҉" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol62" text="◑" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol63" text="❆" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第10行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol64" text="↹" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol65" text="➠" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol66" text="ᨳᤢᤣ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(15)} id="symbol67" text="꧁" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(15)} id="symbol68" text="꧂" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol69" text="☰" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol70" text="☷" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第11行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol71" text="♚" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol72" text="♛" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol73" text="♞" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol74" text="♜" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol75" text="♟" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol76" text="☫" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol77" text="༒" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第12行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol78" text="۞" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol79" text="۩" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol80" text="❂" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol81" text="✪" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol82" text="≼≽" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol83" text="㉿" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol84" text="⊕" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第13行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol85" text="♨" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol86" text="⛖" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol87" text="𖣴" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol88" text="☒" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol89" text="☑" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol90" text="𖡦" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(30)} id="symbol91" text="∞" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第14行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol92" text="ᅟ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol93" text="℃" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol94" text="⌒" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol95" text="⌨" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol96" text="҈" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol97" text="ʚɞ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol98" text="⊱⊰" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第15行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol99" text="♺" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol100" text="⦿" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol101" text="❍" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol102" text="⟐" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol103" text="⎒" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol104" text="༗" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol105" text="卍" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第16行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol106" text="✎" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol107" text="⁃" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol108" text="⁌" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol109" text="⁍" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol110" text="₻" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol111" text="∾" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol112" text="≎" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第17行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol113" text="░" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol114" text="▒" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol115" text="◌" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol116" text="⌭" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol117" text="⌮" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol118" text="⎉" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol119" text="⚘" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第18行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol120" text="𖠚" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol121" text="ᯅ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol122" text="ᴗ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol123" text="ᰔᩚ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol124" text="ಣ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(15)} id="symbol125" text="୧⍤⃝" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(15)} id="symbol126" text="⃟" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第19行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol127" text="ꦿ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol128" text="⚙" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol129" text="পᩚ༅" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol130" text="ཀྃ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol131" text="ꕥ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol132" text="ᝰ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol133" text="ꫛ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <!-- 第20行符号 -->
                    <horizontal>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol134" text="℘" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol135" text="ജ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol136" text="౪ᩚᐝ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol137" text="༊" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol138" text="꧉" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol139" text="ξ" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                        <button textSize={UIScaleManager.textSize(20)} id="symbol140" text="乄" layout_weight="1" style="Widget.AppCompat.Button.Borderless"/>
                    </horizontal>
                    
                    <text id="status" text="点击符号可复制到剪贴板" gravity="center" textColor="#ffffff" textSize={UIScaleManager.textSize(16)}/>
                </vertical>
            </scroll>
        </vertical>
    </frame>
);

// 禁止横屏
ui.emitter.on("config_changed", function(newConfig) {
    if (newConfig.orientation !== android.content.res.Configuration.ORIENTATION_PORTRAIT) {
        // 强制设置为竖屏
        activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }
});
// 初始设置为竖屏
activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
// 启用平滑滚动
ui.scrollView.setSmoothScrollingEnabled(true);
ui.scrollView.setOverScrollMode(android.view.View.OVER_SCROLL_ALWAYS);

// 为所有符号按钮添加点击事件
for (let i = 1; i <= 140; i++) {
    let btn = ui["symbol" + i];
    if (btn) {
        btn.on("click", function() {
            // 点击动画效果
            btn.attr("alpha", "0.7");
            setTimeout(() => {
                btn.attr("alpha", "1");
            }, 100);
            
            // 复制到剪贴板
            setClip(btn.text());
            toast("已复制: " + btn.text());
        });
    }
}

// 显示UI
ui.emitter.on("create", function() {
    ui.status.setText("点击符号可复制到剪贴板");
    // 打印缩放信息用于调试
    UIScaleManager.logInfo();
});