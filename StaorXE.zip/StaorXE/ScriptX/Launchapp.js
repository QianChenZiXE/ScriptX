/*
 * 增强版应用启动器 (2025.06.15)
 * 功能：支持启动无图标应用/系统服务
 * 特点：保留简洁性，增加隐藏应用支持
 */

// 1. 输入对话框（带历史记录）
var appId = rawInput("请输入应用名称/包名/组件名");

// 2. 增强启动逻辑（支持无图标应用）
if (appId) {
    try {
        // 先尝试常规启动方式
        if (!launchApp(appId) && !launchPackage(appId)) {
            // 尝试通过组件名启动
            if (appId.includes("/")) {
                startActivity(appId);
            } else {
                // 尝试通过包名直接启动主Activity
                var pm = context.getPackageManager();
                var intent = pm.getLaunchIntentForPackage(appId);
                if (intent) {
                    context.startActivity(intent);
                } else {
                    // 尝试强制启动
                    intent = new android.content.Intent()
                        .setPackage(appId)
                        .addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK);
                    context.startActivity(intent);
                }
            }
            toast("尝试启动: " + appId);
        }
    } catch (e) {
        toast("启动失败: " + e.message);
    }
}