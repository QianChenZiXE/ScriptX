// 获取包管理器实例
let pm = context.getPackageManager();

// 创建一个意图来过滤出所有已安装的应用程序
let intent = new android.content.Intent(android.content.Intent.ACTION_MAIN, null);
intent.addCategory(android.content.Intent.CATEGORY_LAUNCHER);

// 查询所有符合上述意图的应用程序信息
let resolveInfos = pm.queryIntentActivities(intent, 0);

// 初始化一个空数组用于存放应用信息
let appList = [];

// 遍历查询结果并收集应用信息
for (let resolveInfo of resolveInfos) {
    let activityInfo = resolveInfo.activityInfo;
    if (activityInfo != null) {
        let appName = "" + pm.getApplicationLabel(activityInfo.applicationInfo);
        let packageName = activityInfo.packageName;
        appList.push({appName: appName, packageName: packageName});
    }
}

// 将应用列表转换为字符串格式
let appListStr = appList.map(app => `${app.appName} (${app.packageName})`).join("\n");

// 直接进行日志打印
console.log("应用提取完成，以下是应用列表：\n" + appListStr);
toast("扫描完成 数据已打印至日志");