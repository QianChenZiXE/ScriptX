"ui";
// 引入共享缩放管理器
const ResolutionAdapter = require("./UIScaleManager");
ui.statusBarColor("#5D5D5D");

// 监听缩放变化事件（保持不变）
events.broadcast.on("ui_scale_changed", function(data) {
    ui.view.animate({
        scaleX: data.factor,
        scaleY: data.factor,
        duration: 300
    }).withEndAction(() => {
        ui.finish();
        setTimeout(() => {
            engines.execScriptFile(engines.myEngine().getSource().toString());
        }, 100);
    });
});

// 使用ResolutionAdapter设置所有尺寸，仅增加显示区与按键区的间距
ui.layout(
    <frame bg="#FFFFFF">
        <vertical>
            <!-- 标题区 - 固定在顶部 -->
            <View h={ResolutionAdapter.size(30)} bg="#5D5D5D"/>
            <vertical bg="#5D5D5D">
                <text 
                    gravity="center"
                    textSize={ResolutionAdapter.textSize(30)}
                    textColor="#ffffff" 
                    textStyle="bold" 
                    text="科学计算器"
                />
                <View h={ResolutionAdapter.size(30)} bg="#5D5D5D"/>
            </vertical>
            <scroll>
            <!-- 主内容区 - 使用权重填满剩余空间并居中 -->
            <vertical h="*" gravity="center" bg="#ffffff">
                <!-- 显示区 -->
                <vertical margin={ResolutionAdapter.margin(20)} h={ResolutionAdapter.size(80)}>
                    <text id="formulaDisplay" text="" textSize={ResolutionAdapter.textSize(20)} gravity="right" layout_width="match_parent" margin={ResolutionAdapter.margin(7, 8, 8, -7)} />
                    <text id="currentDisplay" text="0" textSize={ResolutionAdapter.textSize(30)} gravity="right" layout_width="match_parent" margin={ResolutionAdapter.margin(7, 8, 8, -7)}/>
                </vertical>
                
                <!-- 增加间隔距离 -->
                <View h={ResolutionAdapter.size(40)}/>
                
                <!-- 科学函数按钮区域 -->
                <horizontal gravity="center" layout_width="match_parent">
                    <button id="btnSin" text="sin" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#9C27B0"/>
                    <button id="btnCos" text="cos" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#9C27B0"/>
                    <button id="btnTan" text="tan" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#9C27B0"/>
                    <button id="btnLog" text="log" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#9C27B0"/>
                    <button id="btnLn" text="ln" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#9C27B0"/>
                </horizontal>
                
                <horizontal gravity="center" layout_width="match_parent">
                    <button id="btnSqrt" text="√" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#9C27B0"/>
                    <button id="btnPower" text="x^y" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#9C27B0"/>
                    <button id="btnFact" text="n!" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#9C27B0"/>
                    <button id="btnPi" text="π" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#9C27B0"/>
                    <button id="btnE" text="e" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#9C27B0"/>
                </horizontal>
                
                <!-- 增加间隔距离 -->
                <View h={ResolutionAdapter.size(20)}/>
                
                <!-- 按钮区域 -->
                <vertical>
                    <!-- 按钮行1 -->
                    <horizontal gravity="center" layout_width="match_parent">
                        <button id="btnClear" text="AC" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#f44336"/>
                        <button id="btnDel" text="DEL" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#f44336"/>
                        <button id="btnSign" text="+/-" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#757575"/>
                        <button id="btnPercent" text="%" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#757575"/>
                        <button id="btnDivide" text="÷" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#2196F3"/>
                    </horizontal>
                    
                    <!-- 按钮行2 -->
                    <horizontal gravity="center" layout_width="match_parent">
                        <button id="btn7" text="7" layout_weight="1" margin={ResolutionAdapter.margin(2)}/>
                        <button id="btn8" text="8" layout_weight="1" margin={ResolutionAdapter.margin(2)}/>
                        <button id="btn9" text="9" layout_weight="1" margin={ResolutionAdapter.margin(2)}/>
                        <button id="btnMultiply" text="×" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#2196F3"/>
                    </horizontal>
                    
                    <!-- 按钮行3 -->
                    <horizontal gravity="center" layout_width="match_parent">
                        <button id="btn4" text="4" layout_weight="1" margin={ResolutionAdapter.margin(2)}/>
                        <button id="btn5" text="5" layout_weight="1" margin={ResolutionAdapter.margin(2)}/>
                        <button id="btn6" text="6" layout_weight="1" margin={ResolutionAdapter.margin(2)}/>
                        <button id="btnSubtract" text="-" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#2196F3"/>
                    </horizontal>
                    
                    <!-- 按钮行4 -->
                    <horizontal gravity="center" layout_width="match_parent">
                        <button id="btn1" text="1" layout_weight="1" margin={ResolutionAdapter.margin(2)}/>
                        <button id="btn2" text="2" layout_weight="1" margin={ResolutionAdapter.margin(2)}/>
                        <button id="btn3" text="3" layout_weight="1" margin={ResolutionAdapter.margin(2)}/>
                        <button id="btnAdd" text="+" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#2196F3"/>
                    </horizontal>
                    
                    <!-- 按钮行5 -->
                    <horizontal gravity="center" layout_width="match_parent">
                        <button id="btn0" text="0" layout_weight="2" margin={ResolutionAdapter.margin(2)}/>
                        <button id="btnDecimal" text="." layout_weight="1" margin={ResolutionAdapter.margin(2)}/>
                        <button id="btnEquals" text="=" layout_weight="1" margin={ResolutionAdapter.margin(2)} color="#4CAF50"/>
                    </horizontal>
                </vertical>
            </vertical>
            </scroll>
        </vertical>
    </frame>
);

// 禁止横屏
ui.emitter.on("config_changed", function(newConfig) {
    if (newConfig.orientation !== android.content.res.Configuration.ORIENTATION_PORTRAIT) {
        // 强制设置为竖屏
        activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }
});
// 初始设置为竖屏
activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

// 计算器状态
var currentInput = "0";
var previousInput = null;
var operation = null;
var shouldResetInput = false;
var formula = "";
var memoryValue = 0;
var isDegreeMode = true; // true为角度模式，false为弧度模式

// 更新显示
function updateDisplay() {
    ui.currentDisplay.setText(currentInput);
    ui.formulaDisplay.setText(formula);
}

// 数字输入 - 限制9位
function inputDigit(digit) {
    if (currentInput === "0" || shouldResetInput) {
        currentInput = digit;
        shouldResetInput = false;
    } else if (currentInput.replace(/[^0-9]/g, "").length < 9) { // 只计算数字位数
        currentInput += digit;
    }
    updateDisplay();
}

// 小数点输入 - 限制9位
function inputDecimal() {
    if (shouldResetInput) {
        currentInput = "0.";
        shouldResetInput = false;
        updateDisplay();
        return;
    }
    
    if (currentInput.indexOf(".") === -1 && currentInput.length < 9) {
        currentInput += ".";
        updateDisplay();
    }
}

// 删除最后一个字符
function deleteLastChar() {
    if (currentInput === "错误" || currentInput === "溢出" || shouldResetInput) {
        return;
    }
    
    if (currentInput.length === 1) {
        currentInput = "0";
    } else if (currentInput.length === 2 && currentInput.startsWith("-")) {
        currentInput = "0";
    } else {
        currentInput = currentInput.slice(0, -1);
    }
    
    if (currentInput === ".") {
        currentInput = "0";
    }
    
    updateDisplay();
}

// 设置运算操作
function setOperation(op) {
    if (currentInput === "0" && previousInput === null) return;
    
    if (previousInput !== null && !shouldResetInput) {
        calculate(false);
    }
    
    operation = op;
    previousInput = currentInput;
    formula = previousInput + " " + operation;
    shouldResetInput = true;
    updateDisplay();
}

// 计算结果 - 限制9位
function calculate(showResult) {
    if (previousInput === null || operation === null) return;
    
    var result;
    var prev = parseFloat(previousInput);
    var curr = parseFloat(currentInput);
    
    switch (operation) {
        case "+": result = prev + curr; break;
        case "-": result = prev - curr; break;
        case "×": result = prev * curr; break;
        case "÷": 
            if (curr === 0) {
                currentInput = "错误";
                formula = "";
                previousInput = null;
                operation = null;
                shouldResetInput = true;
                updateDisplay();
                return;
            }
            result = prev / curr; 
            break;
        case "x^y": result = Math.pow(prev, curr); break;
        default: return;
    }
    
    // 限制结果长度不超过9位
    var resultStr = result.toString();
    if (resultStr.length > 9) {
        if (resultStr.indexOf(".") !== -1) {
            resultStr = resultStr.substring(0, 9);
        } else {
            currentInput = "溢出";
            formula = "";
            previousInput = null;
            operation = null;
            shouldResetInput = true;
            updateDisplay();
            return;
        }
    }
    
    if (showResult) {
        formula += " " + currentInput + " =";
    }
    currentInput = resultStr;
    previousInput = showResult ? null : resultStr;
    operation = showResult ? null : operation;
    shouldResetInput = showResult;
    updateDisplay();
}

// 清除所有
function clearAll() {
    currentInput = "0";
    previousInput = null;
    operation = null;
    formula = "";
    shouldResetInput = false;
    updateDisplay();
}

// 正负号切换
function toggleSign() {
    currentInput = (parseFloat(currentInput) * -1).toString();
    updateDisplay();
}

// 百分比计算
function inputPercent() {
    currentInput = (parseFloat(currentInput) / 100).toString();
    updateDisplay();
}

// 科学计算函数 - 限制9位
function calculateSin() {
    var value = parseFloat(currentInput);
    if (!isDegreeMode) {
        value = value * Math.PI / 180;
    }
    var result = Math.sin(value).toString();
    if (result.length > 9) {
        result = result.substring(0, 9);
    }
    currentInput = result;
    formula = "sin(" + value + ")";
    shouldResetInput = true;
    updateDisplay();
}

function calculateCos() {
    var value = parseFloat(currentInput);
    if (!isDegreeMode) {
        value = value * Math.PI / 180;
    }
    var result = Math.cos(value).toString();
    if (result.length > 9) {
        result = result.substring(0, 9);
    }
    currentInput = result;
    formula = "cos(" + value + ")";
    shouldResetInput = true;
    updateDisplay();
}

function calculateTan() {
    var value = parseFloat(currentInput);
    if (!isDegreeMode) {
        value = value * Math.PI / 180;
    }
    var result = Math.tan(value).toString();
    if (result.length > 9) {
        result = result.substring(0, 9);
    }
    currentInput = result;
    formula = "tan(" + value + ")";
    shouldResetInput = true;
    updateDisplay();
}

function calculateLog() {
    var result = Math.log10(parseFloat(currentInput)).toString();
    if (result.length > 9) {
        result = result.substring(0, 9);
    }
    currentInput = result;
    formula = "log(" + currentInput + ")";
    shouldResetInput = true;
    updateDisplay();
}

function calculateLn() {
    var result = Math.log(parseFloat(currentInput)).toString();
    if (result.length > 9) {
        result = result.substring(0, 9);
    }
    currentInput = result;
    formula = "ln(" + currentInput + ")";
    shouldResetInput = true;
    updateDisplay();
}

function calculateSqrt() {
    var result = Math.sqrt(parseFloat(currentInput)).toString();
    if (result.length > 9) {
        result = result.substring(0, 9);
    }
    currentInput = result;
    formula = "√(" + currentInput + ")";
    shouldResetInput = true;
    updateDisplay();
}

function calculatePower() {
    setOperation("x^y");
}

function calculateFact() {
    var num = parseInt(currentInput);
    if (num < 0) {
        currentInput = "错误";
    } else if (num === 0 || num === 1) {
        currentInput = "1";
    } else {
        var result = 1;
        for (var i = 2; i <= num; i++) {
            result *= i;
        }
        currentInput = result.toString();
    }
    formula = num + "!";
    shouldResetInput = true;
    updateDisplay();
}

function inputPi() {
    currentInput = Math.PI.toString().substring(0, 9);
    shouldResetInput = true;
    updateDisplay();
}

function inputE() {
    currentInput = Math.E.toString().substring(0, 9);
    shouldResetInput = true;
    updateDisplay();
}

// 按钮事件绑定
ui.btn0.click(function() { inputDigit("0"); });
ui.btn1.click(function() { inputDigit("1"); });
ui.btn2.click(function() { inputDigit("2"); });
ui.btn3.click(function() { inputDigit("3"); });
ui.btn4.click(function() { inputDigit("4"); });
ui.btn5.click(function() { inputDigit("5"); });
ui.btn6.click(function() { inputDigit("6"); });
ui.btn7.click(function() { inputDigit("7"); });
ui.btn8.click(function() { inputDigit("8"); });
ui.btn9.click(function() { inputDigit("9"); });

ui.btnDecimal.click(inputDecimal);
ui.btnClear.click(clearAll);
ui.btnDel.click(deleteLastChar);
ui.btnSign.click(toggleSign);
ui.btnPercent.click(inputPercent);

ui.btnAdd.click(function() { setOperation("+"); });
ui.btnSubtract.click(function() { setOperation("-"); });
ui.btnMultiply.click(function() { setOperation("×"); });
ui.btnDivide.click(function() { setOperation("÷"); });

ui.btnEquals.click(function() { calculate(true); });

// 科学函数按钮绑定
ui.btnSin.click(calculateSin);
ui.btnCos.click(calculateCos);
ui.btnTan.click(calculateTan);
ui.btnLog.click(calculateLog);
ui.btnLn.click(calculateLn);
ui.btnSqrt.click(calculateSqrt);
ui.btnPower.click(calculatePower);
ui.btnFact.click(calculateFact);
ui.btnPi.click(inputPi);
ui.btnE.click(inputE);

// 初始化显示
updateDisplay();

// 监听返回键
ui.emitter.on("back_pressed", () => {
    ui.finish();
});
