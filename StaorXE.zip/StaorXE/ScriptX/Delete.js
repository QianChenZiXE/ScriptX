        // 指定要操作的文件夹路径
const folderPath = "/sdcard/ScriptX/";
// 定义白名单，白名单中的文件或文件夹不会被删除
const whiteList = [
    
    "ScriptX.js"
   
];

// 函数：删除文件夹内的所有文件
function deleteFilesInFolder(folder) {
    if (files.exists(folder)) {
        let fileList = files.listDir(folder);
        for (let file of fileList) {
            let curPath = files.join(folder, file);
            let isInWhiteList = whiteList.some((item) => {
                // 检查当前路径是否在白名单中
                return curPath.endsWith(item);
            });
            if (isInWhiteList) {
                // 如果在白名单中，跳过不处理
                continue;
            }
            if (files.isDir(curPath)) {
                // 如果是子文件夹，递归删除子文件夹内的文件
                deleteFilesInFolder(curPath);
            } else {
                try {
                    files.remove(curPath);
                    //console.log(`已删除文件: ${curPath}`);
                } catch (error) {
                    //console.error(`删除文件 ${curPath} 时出错: `, error);
                }
            }
        }
    }
}

deleteFilesInFolder(folderPath);
console.log(`${folderPath} 原文件文件已成功删除`);

