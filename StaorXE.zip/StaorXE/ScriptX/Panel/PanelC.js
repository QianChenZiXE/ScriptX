"ui";
// 添加必要的权限声明
const UIScaleManager = require("./UIScaleManager");

ui.statusBarColor("#5D5D5D");

// ==================== UI布局 ====================
ui.layout(
  <scroll>
    <vertical>
      {/* 顶部装饰条 */}
      <text 
        text="" 
        padding={UIScaleManager.margin(20)} 
        textSize={UIScaleManager.textSize(10)} 
        bg="#5D5D5D" 
        gravity="center"
      />

      {/* 标题部分 - 靠上显示 */}
      <vertical padding="0" marginTop={UIScaleManager.size(50)}>
        <text 
          text="监测面板" 
          textSize={UIScaleManager.textSize(30)} 
          textColor="#5D5D5D" 
          gravity="center"
        />
      </vertical>

      {/* 监测数据部分 - 整体居中 */}
      <vertical
        padding={UIScaleManager.margin(5)} 
        marginTop={UIScaleManager.size(50)}
        gravity="center"
        layout_gravity="center"
      >
        <frame gravity="center" layout_gravity="center">
          <vertical>
            {/* 帧率FPS */}
            <horizontal marginBottom={UIScaleManager.size(8)}>
              <text text="帧率FPS:" textSize={UIScaleManager.textSize(14)} textColor="#555555" gravity="left"/>
              <text id="fpsCounter" textSize={UIScaleManager.textSize(14)} textColor="#00BCD4" marginLeft={UIScaleManager.size(8)} gravity="left"/>
            </horizontal>
            
            {/* CPU使用 */}
            <horizontal marginBottom={UIScaleManager.size(8)}>
              <text text="CPU使用:" textSize={UIScaleManager.textSize(14)} textColor="#555555" gravity="left"/>
              <text id="cpuUsage" textSize={UIScaleManager.textSize(14)} textColor="#4CAF50" marginLeft={UIScaleManager.size(8)} gravity="left"/>
            </horizontal>
            
            {/* 充电状态 */}
            <horizontal marginBottom={UIScaleManager.size(8)}>
              <text text="充电状态:" textSize={UIScaleManager.textSize(14)} textColor="#555555" gravity="left"/>
              <text id="chargingStatus" textSize={UIScaleManager.textSize(14)} textColor="#9C27B0" marginLeft={UIScaleManager.size(8)} gravity="left"/>
            </horizontal>         
            
            {/* 电池温度 */}
            <horizontal marginBottom={UIScaleManager.size(8)}>
              <text text="电池温度:" textSize={UIScaleManager.textSize(14)} textColor="#555555" gravity="left"/>
              <text id="batteryTemp" textSize={UIScaleManager.textSize(14)} textColor="#FF5722" marginLeft={UIScaleManager.size(8)} gravity="left"/>
            </horizontal>
            
            {/* 内存使用 */}
            <horizontal marginBottom={UIScaleManager.size(8)}>
              <text text="内存使用:" textSize={UIScaleManager.textSize(14)} textColor="#555555" gravity="left"/>
              <text id="memUsage" textSize={UIScaleManager.textSize(14)} textColor="#2196F3" marginLeft={UIScaleManager.size(8)} gravity="left"/>
            </horizontal>     
            
            {/* 手机信号 */}
            <horizontal marginBottom={UIScaleManager.size(8)}>
              <text text="手机信号:" textSize={UIScaleManager.textSize(14)} textColor="#555555" gravity="left"/>
              <text id="mobileSignal" textSize={UIScaleManager.textSize(14)} textColor="#FF5252" marginLeft={UIScaleManager.size(8)} gravity="left"/>
            </horizontal>  
      
            {/* WiFi强度 */}
            <horizontal marginBottom={UIScaleManager.size(8)}>
              <text text="WiFi强度:" textSize={UIScaleManager.textSize(14)} textColor="#555555" gravity="left"/>
              <text id="wifiStrength" textSize={UIScaleManager.textSize(14)} textColor="#FF9800" marginLeft={UIScaleManager.size(8)} gravity="left"/>
            </horizontal>

            {/* 网络速度 */}
            <horizontal marginBottom={UIScaleManager.size(8)}>
              <text text="网络速度:" textSize={UIScaleManager.textSize(14)} textColor="#555555" gravity="left"/>
              <text id="networkSpeed" textSize={UIScaleManager.textSize(14)} textColor="#673AB7" marginLeft={UIScaleManager.size(8)} gravity="left"/>
            </horizontal>
            
            {/* 存储信息 */}
            <horizontal marginBottom={UIScaleManager.size(8)}>
              <text text="存储信息:" textSize={UIScaleManager.textSize(14)} textColor="#555555" gravity="left"/>
              <text id="storageInfo" textSize={UIScaleManager.textSize(14)} textColor="#795548" marginLeft={UIScaleManager.size(8)} gravity="left"/>
            </horizontal>
            
            {/* 年度进度 */}
            <horizontal marginBottom={UIScaleManager.size(8)}>
              <text text="年度进度:" textSize={UIScaleManager.textSize(14)} textColor="#555555" gravity="left"/>
              <text id="yearProgress" textSize={UIScaleManager.textSize(14)} textColor="#607D8B" marginLeft={UIScaleManager.size(8)} gravity="left"/>
            </horizontal>
          </vertical>
        </frame>
      </vertical>
    </vertical>
  </scroll>
)
// 禁止横屏
ui.emitter.on("config_changed", function(newConfig) {
    if (newConfig.orientation !== android.content.res.Configuration.ORIENTATION_PORTRAIT) {
        // 强制设置为竖屏
        activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);
    }
});
// 初始设置为竖屏
activity.setRequestedOrientation(android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

// ==================== 权限检查 ====================
function checkUsageStatsPermission() {
    if (device.sdkInt >= 21) {
        let usm = context.getSystemService(context.USAGE_STATS_SERVICE);
        if (!usm.isAppUsagePermissionGranted()) {
            toast("请授予使用统计权限");
            app.startActivity(new Intent(android.provider.Settings.ACTION_USAGE_ACCESS_SETTINGS));
            return false;
        }
    }
    return true;
}
 
// ==================== 内存监控 ====================
const MEM_BAR_WIDTH = 20;
const MEM_UPDATE_INTERVAL = 1000;

let lastMemLevel = 0;
let lastMemUpdate = 0;

function getMemoryInfo() {
    let now = Date.now();
    if (now - lastMemUpdate < MEM_UPDATE_INTERVAL) {
        return ui.memUsage.getText();
    }
    lastMemUpdate = now;

    try {
        let total = device.totalMem / 1048576; // MB
        let avail = device.availMem / 1048576;
        let used = total - avail;
        let percent = (used / total * 100);
        
        lastMemLevel = 0.6 * lastMemLevel + 0.4 * percent;
        let smoothPercent = Math.max(0, Math.min(100, lastMemLevel));
        
        let filled = Math.floor((smoothPercent / 100) * MEM_BAR_WIDTH);
        let bar = "[" + "█".repeat(filled) + "░".repeat(MEM_BAR_WIDTH - filled) + "]]";
        
        return `${bar} ${smoothPercent.toFixed(1)}% (${used.toFixed(1)}/${total.toFixed(1)}MB)`;
    } catch (e) {
        return `[${"░".repeat(MEM_BAR_WIDTH)}] N/A`;
    }
}

// ==================== CPU负载检测 ====================
const CPU_BAR_WIDTH = 20;
let lastCpuLevel = 0;

function getCpuLoad() {
    try {
        let currentFreq = "N/A";
        let maxFreq = "N/A";
        let freqPercent = 50;
        
        try {
            maxFreq = files.read("/sys/devices/system/cpu/cpu0/cpufreq/cpuinfo_max_freq");
            maxFreq = parseInt(maxFreq) / 1000;
            currentFreq = files.read("/sys/devices/system/cpu/cpu0/cpufreq/scaling_cur_freq");
            currentFreq = parseInt(currentFreq) / 1000;
            freqPercent = Math.min(100, (currentFreq / maxFreq) * 100);
        } catch (e) {
            let now = Date.now();
            let elapsed = now - (lastCpuUpdate || now);
            lastCpuUpdate = now;
            let activity = Math.min(100, elapsed / 10);
            freqPercent = Math.min(100, Math.max(0, lastCpuLevel + activity));
        }
        
        lastCpuLevel = (lastCpuLevel * 0.7) + (freqPercent * 0.3);
        let smoothedUsage = Math.max(0, Math.min(100, lastCpuLevel));
        
        let filled = Math.floor((smoothedUsage / 100) * CPU_BAR_WIDTH);
        let bar = "[" + "█".repeat(filled) + "░".repeat(CPU_BAR_WIDTH - filled) + "]";
        
        let freqInfo = currentFreq !== "N/A" ? ` ${currentFreq}MHz/${maxFreq}MHz` : "";
        return `${bar}] ${smoothedUsage.toFixed(1)}%${freqInfo}`;
    } catch ( e) {
        return `[${"░".repeat(CPU_BAR_WIDTH)}] N/A`;
    }
}

// ==================== 电池温度检测 ====================
const TEMP_BAR_WIDTH = 20;
const MIN_TEMP = 20;
const MAX_TEMP = 60;
const TEMP_UPDATE_INTERVAL = 1000;

let lastTempLevel = 0;
let lastTempUpdate = 0;

function getBatteryTemperature() {
    let now = Date.now();
    if (now - lastTempUpdate < TEMP_UPDATE_INTERVAL) {
        return ui.batteryTemp.getText();
    }
    lastTempUpdate = now;

    try {
        let temp = null;
        let intent = context.registerReceiver(null, 
            new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED));
        
        if (intent) {
            let rawTemp = intent.getIntExtra("temperature", -1);
            if (rawTemp > 0) temp = rawTemp / 10.0;
        }
        
        if (temp == null) {
            let paths = ["/sys/class/power_supply/battery/temp",
                        "/sys/class/power_supply/battery/batt_temp",
                        "/sys/class/thermal/thermal_zone0/temp"];
            
            for (let path of paths) {
                if (files.exists(path)) {
                    let content = files.read(path).trim();
                    if (!isNaN(content)) {
                        let rawValue = parseFloat(content);
                        temp = rawValue > 100 ? rawValue / 10.0 : rawValue;
                        break;
                    }
                }
            }
        }
        
        if (temp == null) return `[${"░".repeat(TEMP_BAR_WIDTH)}] N/A`;
        
        let tempPercent = Math.min(100, Math.max(0, (temp - MIN_TEMP) / (MAX_TEMP - MIN_TEMP) * 100));
        lastTempLevel = (lastTempLevel * 0.7) + (tempPercent * 0.3);
        let smoothedPercent = Math.max(0, Math.min(100, lastTempLevel));
        
        let filled = Math.floor((smoothedPercent / 100) * TEMP_BAR_WIDTH);
        let bar = "[" + "█".repeat(filled) + "░".repeat(TEMP_BAR_WIDTH - filled) + "]]";
        
        return `${bar} ${temp.toFixed(1)}°C`;
    } catch (e) {
        return `[${"░".repeat(TEMP_BAR_WIDTH)}] N/A`;
    }
}

// ==================== 充电状态检测（兼容版） ====================
const CHARGE_BAR_WIDTH = 20;
let lastChargeStatus = "";
let lastChargeLevel = 0;

function getChargingStatus() {
    try {
        let intent = context.registerReceiver(null, 
            new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED));
        
        if (intent) {
            let status = intent.getIntExtra("status", -1);
            let plugged = intent.getIntExtra("plugged", -1);
            let level = intent.getIntExtra("level", -1);
            let scale = intent.getIntExtra("scale", 100);
            let batteryPercent = Math.round(level * 100 / scale);
            
            // 平滑电量百分比
            lastChargeLevel = (lastChargeLevel * 0.8) + (batteryPercent * 0.2);
            let smoothedPercent = Math.max(0, Math.min(100, lastChargeLevel));
            
            // 生成电量条
            let filled = Math.floor(smoothedPercent / 100 * CHARGE_BAR_WIDTH);
            let bar = "[" + "█".repeat(filled) + "░".repeat(CHARGE_BAR_WIDTH - filled) + "]]";
            
            // 判断充电状态
            if (status === android.os.BatteryManager.BATTERY_STATUS_CHARGING) {
                let statusText = "充电中";
                if (plugged === android.os.BatteryManager.BATTERY_PLUGGED_AC) {
                    statusText = "AC充电";
                } else if (plugged === android.os.BatteryManager.BATTERY_PLUGGED_USB) {
                    statusText = "USB充电";
                } else if (plugged === android.os.BatteryManager.BATTERY_PLUGGED_WIRELESS) {
                    statusText = "无线充电";
                }
                
                // 兼容的快充检测方案
                try {
                    // Android 6.0+ 官方API
                    if (android.os.Build.VERSION.SDK_INT >= 23) {
                        let chargeRate = intent.getIntExtra("charge_counter", -1);
                        if (chargeRate > 2000) { // 经验值，大于2A可能是快充
                            statusText += "(快充)";
                        }
                    }
                    // 备用方案：通过电流检测
                    else if (files.exists("/sys/class/power_supply/battery/current_now")) {
                        let current = parseInt(files.read("/sys/class/power_supply/battery/current_now"));
                        if (current > 2000000) { // 大于2A
                            statusText += "(快充)";
                        }
                    }
                } catch(e) {
                    console.log("快充检测失败:", e);
                }
                
                return `${bar} ${smoothedPercent}% ${statusText}`;
            } 
            else if (status === android.os.BatteryManager.BATTERY_STATUS_DISCHARGING) {
                let statusText = smoothedPercent < 15 ? "电量不足" : 
                               smoothedPercent < 30 ? "低电量" : "未充电";
                return `${bar} ${smoothedPercent}% ${statusText}`;
            }
            else if (status === android.os.BatteryManager.BATTERY_STATUS_FULL) {
                return `${bar} 100% 已充满`;
            }
            else {
                return `${bar} ${smoothedPercent}% 未知状态`;
            }
        }
    } catch (e) {
        console.log("获取充电状态失败:", e);
    }
    return `[${"░".repeat(CHARGE_BAR_WIDTH)}] N/A`;
}

// ==================== WiFi强度检测 (100级版) ====================
const WIFI_REFRESH_INTERVAL = 1000;
const WIFI_SMOOTH_FACTOR = 0.4;
const MIN_RSSI = -100;  // 最小信号强度
const MAX_RSSI = -30;   // 最大信号强度
const WIFI_MAX_LEVEL = 100; // 改为100级

let lastWifiLevel = 0;
let lastWifiUpdate = 0;

function getWifiStrength() {
    let now = Date.now();
    if (now - lastWifiUpdate < WIFI_REFRESH_INTERVAL) {
        return ui.wifiStrength.getText();
    }
    lastWifiUpdate = now;

    try {
        let wifiManager = context.getSystemService(context.WIFI_SERVICE);
        let wifiInfo = wifiManager.getConnectionInfo();
        let rssi = wifiInfo.getRssi();
        
        // 计算100级信号强度
        let level = android.net.wifi.WifiManager.calculateSignalLevel(rssi, WIFI_MAX_LEVEL);
        
        // 平滑处理
        lastWifiLevel = Math.max(0, Math.min(WIFI_MAX_LEVEL - 1, 
            (lastWifiLevel * (1 - WIFI_SMOOTH_FACTOR)) + (level * WIFI_SMOOTH_FACTOR)));
        
        let smoothedLevel = Math.round(lastWifiLevel);
        let filled = Math.floor(smoothedLevel / (WIFI_MAX_LEVEL / 20)); // 保持20字符进度条宽度
        let bar = "[" + "█".repeat(filled) + "░".repeat(20 - filled) + "]]";
        
        // 计算信号百分比
        let percentage = Math.min(100, Math.max(0, 
            ((rssi - MIN_RSSI) / (MAX_RSSI - MIN_RSSI)) * 100));
        
        // 获取SSID（隐藏敏感信息）
        let ssid = wifiInfo.getSSID();
        ssid = ssid ? ssid.replace(/["]/g, "").substring(0, 10) + (ssid.length > 10 ? "..." : "") : "未知";
        
        return `${bar} ${smoothedLevel.toString().padStart(3)}/100 (${percentage.toFixed(0)}%)${rssi}dBm`;
        
    } catch (e) {
        return "[░░░░░░░░░░░░░░░░░░░░]   0/100 (无连接)";
    }
}
 
// ==================== FPS帧率检测 ====================
const FPS_BAR_WIDTH = 20;
let lastFrameTime = Date.now();
let frameCount = 0;
let lastFps = 0;

// 更可靠的刷新率获取方法
function getRefreshRate() {
    try {
        // 方法1：通过Display获取（需要Android 4.4+）
        if (context.getSystemService) {
            let windowManager = context.getSystemService(context.WINDOW_SERVICE);
            let display = windowManager.getDefaultDisplay();
            
            // Android 4.4-7.1
            if (display.getRefreshRate) {
                return Math.round(display.getRefreshRate());
            }
            
            // Android 8.0+ 新API
            if (display.getMode && display.getMode().getRefreshRate) {
                return Math.round(display.getMode().getRefreshRate());
            }
        }
        
        // 方法2：通过设备特征猜测
        let width = device.width;
        let height = device.height;
        if (width >= 1440 || height >= 3120) return 120; // 2K+设备
        if (width >= 1080 && height >= 2400) return 90;   // 1080p高刷
        
    } catch(e) {
        console.error("获取刷新率失败:", e);
    }
    return 60; // 默认值
}

const maxRefreshRate = getRefreshRate();
let lastFpsUpdate = 0;

function updateFps() {
    frameCount++;
    let now = Date.now();
    let elapsed = now - lastFrameTime;
    
    // 每秒计算一次FPS
    if (elapsed >= 1000) {
        let currentFps = Math.round((frameCount * 1000) / elapsed);
        frameCount = 0;
        lastFrameTime = now;
        
        // 平滑处理（减少跳动）
        lastFps = (lastFps * 0.6) + (currentFps * 0.4);
        let displayFps = Math.min(maxRefreshRate, Math.max(0, lastFps));
        
        // 生成进度条
        let filled = Math.floor((displayFps / maxRefreshRate) * FPS_BAR_WIDTH);
        let bar = "[" + "█".repeat(filled) + "░".repeat(FPS_BAR_WIDTH - filled) + "]]";
        
        // 更新UI
        ui.run(() => {
            ui.fpsCounter.setText(`${bar} ${Math.round(displayFps)}FPS (${maxRefreshRate}Hz)`);
        });
    }
}

// ==================== 网络速度检测 (100级版) ====================
const NET_BAR_WIDTH = 20;
const MAX_NET_SPEED = 10 * 1024 * 1024; // 10MB/s为100%

let lastRxBytes = 0;
let lastTxBytes = 0;
let lastNetUpdate = Date.now();
let lastNetLevel = 0;

function getNetworkSpeed() {
    try {
        let stats = android.net.TrafficStats.getTotalRxBytes();
        let txStats = android.net.TrafficStats.getTotalTxBytes();
        let now = Date.now();
        let elapsed = (now - lastNetUpdate) / 1000;
        
        if (elapsed > 0) {
            let rxSpeed = (stats - lastRxBytes) / elapsed;
            let txSpeed = (txStats - lastTxBytes) / elapsed;
            lastRxBytes = stats;
            lastTxBytes = txStats;
            lastNetUpdate = now;
            
            let totalSpeed = rxSpeed + txSpeed;
            let speedMB = totalSpeed / (1024 * 1024); // 转换为MB/s
            
            // 新的进度计算逻辑
            let speedPercent = 0;
            if (speedMB <= 1) {
                speedPercent = Math.floor(speedMB * 10); // 0-1MB → 0-10%
            } else if (speedMB <= 2) {
                speedPercent = 10 + Math.floor((speedMB - 1) * 10); // 1-2MB → 10-20%
            } else if (speedMB <= 3) {
                speedPercent = 20 + Math.floor((speedMB - 2) * 10); // 2-3MB → 20-30%
            } else if (speedMB <= 4) {
                speedPercent = 30 + Math.floor((speedMB - 3) * 10); // 3-4MB → 30-40%
            } else if (speedMB <= 5) {
                speedPercent = 40 + Math.floor((speedMB - 4) * 10); // 4-5MB → 40-50%
            } else if (speedMB <= 6) {
                speedPercent = 50 + Math.floor((speedMB - 5) * 10); // 5-6MB → 50-60%
            } else if (speedMB <= 7) {
                speedPercent = 60 + Math.floor((speedMB - 6) * 10); // 6-7MB → 60-70%
            } else if (speedMB <= 8) {
                speedPercent = 70 + Math.floor((speedMB - 7) * 10); // 7-8MB → 70-80%
            } else if (speedMB <= 9) {
                speedPercent = 80 + Math.floor((speedMB - 8) * 10); // 8-9MB → 80-90%
            } else {
                speedPercent = 90 + Math.min(10, Math.floor((speedMB - 9) * 10)); // 9MB+ → 90-100%
            }
            
            // 平滑处理
            lastNetLevel = Math.min(100, (lastNetLevel * 0.7) + (speedPercent * 0.3));
            
            // 生成进度条（保持20字符宽度）
            let filled = Math.floor(lastNetLevel / 5); // 100级/20字符=每5%一个█
            let bar = "[" + "█".repeat(filled) + "░".repeat(NET_BAR_WIDTH - filled) + "]]";
            
            // 格式化速度显示
            let formatSpeed = (speed) => {
                if (speed > 1024 * 1024) return (speed / (1024 * 1024)).toFixed(1) + "MB";
                return (speed / 1024).toFixed(1) + "KB";
            };
            
            return `${bar} ${Math.round(lastNetLevel)}% ↓${formatSpeed(rxSpeed)}/s ↑${formatSpeed(txSpeed)}/s`;
        }
    } catch (e) {
        console.log("获取网络速度失败:", e);
    }
    return `[${"░".repeat(NET_BAR_WIDTH)}] 0% N/A`;
}
 
// ==================== 存储空间检测 ====================
const STORAGE_BAR_WIDTH = 20;
let lastStorageLevel = 0;

function getStorageInfo() {
    try {
        let stat = new android.os.StatFs(context.getExternalFilesDir(null).getPath());
        let blockSize = stat.getBlockSizeLong();
        let totalBlocks = stat.getBlockCountLong();
        let availableBlocks = stat.getAvailableBlocksLong();
        
        let total = (totalBlocks * blockSize) / (1024 * 1024 * 1024);
        let free = (availableBlocks * blockSize) / (1024 * 1024 * 1024);
        let used = total - free;
        let percent = (used / total * 100);
        
        lastStorageLevel = (lastStorageLevel * 0.7) + (percent * 0.3);
        let smoothedPercent = Math.max(0, Math.min(100, lastStorageLevel));
        
        let filled = Math.floor(smoothedPercent / 100 * STORAGE_BAR_WIDTH);
        let bar = "[" + "█".repeat(filled) + "░".repeat(STORAGE_BAR_WIDTH - filled) + "]]";
        
        return `${bar} ${smoothedPercent.toFixed(1)}% (${used.toFixed(1)}/${total.toFixed(1)}GB)`;
    } catch (e) {
        return `[${"░".repeat(STORAGE_BAR_WIDTH)}] N/A`;
    }
}

// ==================== 年度进度检测 ====================
function getYearProgress() {
    const YEAR_BAR_WIDTH = 20;
    const now = new Date();
    const year = now.getFullYear();
    
    // 判断是否是闰年
    const isLeapYear = (year % 400 === 0) || (year % 100 !== 0 && year % 4 === 0);
    const daysInYear = isLeapYear ? 366 : 365;
    
    // 计算今年第一天和今天的时间差
    const startOfYear = new Date(year, 0, 1);
    const diff = now - startOfYear;
    const dayOfYear = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    // 计算百分比
    const percent = (dayOfYear / daysInYear) * 100;
    
    // 生成进度条
    const filled = Math.floor(percent / 100 * YEAR_BAR_WIDTH);
    const bar = "[" + "█".repeat(filled) + "░".repeat(YEAR_BAR_WIDTH - filled) + "]]";
    
    // 格式化日期信息
    const monthNames = ["一月", "二月", "三月", "四月", "五月", "六月", 
                       "七月", "八月", "九月", "十月", "十一月", "十二月"];
    const monthName = monthNames[now.getMonth()];
    const day = now.getDate();
    
    return `${bar} ${percent.toFixed(2)}% (${monthName}${day}日, ${dayOfYear}/${daysInYear}天)`;
}

 
// ==================== 兼容所有Android版本的信号检测 ====================
const SIGNAL_BAR_WIDTH = 20;
const SIGNAL_UPDATE_INTERVAL = 1000;

function getMobileSignal() {
    try {
        let telephony = context.getSystemService(context.TELEPHONY_SERVICE);
        let signalStrength = telephony.getSignalStrength();
        let networkType = getNetworkTypeName(telephony);
        let result = { dbm: -120, level: -1 };

        // 优先级：5G > LTE > WCDMA > GSM > 通用方法
        if (android.os.Build.VERSION.SDK_INT >= 29) {
            result = tryGetSignal(signalStrength, "getCellSignalStrengthNr") || result; // 5G
        }
        result = tryGetSignal(signalStrength, "getCellSignalStrengthLte") || result;  // 4G
        result = tryGetSignal(signalStrength, "getCellSignalStrengthWcdma") || result; // 3G
        result = tryGetSignal(signalStrength, "getCellSignalStrengthGsm") || result;   // 2G
        
        // 最终回退到通用方法
        if (result.dbm <= -120) {
            result.dbm = tryGetDbmByReflection(signalStrength) || result.dbm;
            result.level = tryGetLevelByReflection(signalStrength) || result.level;
        }

        return formatSignalResult(result.dbm, result.level, networkType);
    } catch (e) {
        console.error("信号检测失败:", e);
        return `[${"░".repeat(SIGNAL_BAR_WIDTH)}] N/A`;
    }
}

// 尝试获取特定网络类型的信号
function tryGetSignal(signalStrength, methodName) {
    try {
        if (signalStrength.getClass().getMethod(methodName)) {
            let signal = signalStrength[methodName]();
            let dbm = signal.getDbm();
            let level = signal.getLevel();
            if (dbm > -120) return { dbm, level };
        }
    } catch (e) {
        // 方法不存在时静默失败
    }
    return null;
}

// 通过反射获取dbm（兼容旧设备）
function tryGetDbmByReflection(obj) {
    try {
        return obj.getClass().getMethod("getDbm").invoke(obj);
    } catch (e) {
        return null;
    }
}

// 通过反射获取level（兼容旧设备）
function tryGetLevelByReflection(obj) {
    try {
        return obj.getClass().getMethod("getLevel").invoke(obj);
    } catch (e) {
        return null;
    }
}

// 获取网络类型名称
function getNetworkTypeName(telephony) {
    const types = {
        1: "2G", 2: "2G", 3: "3G", 4: "3G", 5: "3G", 
        13: "4G", 20: "5G"
    };
    try {
        let type = telephony.getNetworkType();
        return types[type] || telephony.getNetworkTypeName() || "N/A";
    } catch (e) {
        return "N/A";
    }
}

// 格式化信号结果
function formatSignalResult(dbm, level, networkType) {
    let percent = mapSignalLevel(dbm, level);
    let filled = Math.floor((percent / 100) * SIGNAL_BAR_WIDTH);
    let bar = "[" + "█".repeat(filled) + "░".repeat(SIGNAL_BAR_WIDTH - filled) + "]]";
    
    return dbm > -120 
        ? `${bar} ${percent}% (${dbm}dBm) ${networkType}`
        : `[${"░".repeat(SIGNAL_BAR_WIDTH)}] N/A`;
}

// 信号强度映射
function mapSignalLevel(dbm, level) {
    // 优先使用系统提供的level
    if (level != null && level >= 0 && level <= 4) {
        return (level + 1) * 20;
    }
    // 根据dbm估算
    if (dbm >= -50) return 100;
    if (dbm >= -60) return 80;
    if (dbm >= -70) return 60;
    if (dbm >= -80) return 40;
    if (dbm >= -90) return 20;
    return 0;
}
 

// ==================== 主更新函数 ====================
function updateAll() {
    ui.run(() => {
        ui.memUsage.setText(getMemoryInfo());
        ui.cpuUsage.setText(getCpuLoad());
        ui.batteryTemp.setText(getBatteryTemperature());
        ui.chargingStatus.setText(getChargingStatus());
        ui.wifiStrength.setText(getWifiStrength());
        ui.networkSpeed.setText(getNetworkSpeed());
        ui.storageInfo.setText(getStorageInfo());
        ui.yearProgress.setText(getYearProgress());
        ui.mobileSignal.setText(getMobileSignal());
    });
}

// ==================== 初始化 ====================
// 立即显示初始状态
ui.run(() => {
    ui.fpsCounter.setText(`[${"░".repeat(FPS_BAR_WIDTH)}] 检测中...`);
    ui.memUsage.setText(`[${"░".repeat(MEM_BAR_WIDTH)}] 检测中...`);
    ui.cpuUsage.setText(`[${"░".repeat(CPU_BAR_WIDTH)}] 检测中...`);
    ui.batteryTemp.setText(`[${"░".repeat(TEMP_BAR_WIDTH)}] 检测中...`);
    ui.chargingStatus.setText(`[${"░".repeat(CHARGE_BAR_WIDTH)}] 检测中...`);
    ui.wifiStrength.setText("[░░░░░░░░░░░░░░░░░░░░] 检测中...");
    ui.networkSpeed.setText(`[${"░".repeat(NET_BAR_WIDTH)}] 检测中...`);
    ui.storageInfo.setText(`[${"░".repeat(STORAGE_BAR_WIDTH)}] 检测中...`);
    ui.yearProgress.setText(`[${"░".repeat(20)}] 计算中...`);
    ui.mobileSignal.setText("[░░░░░░░░░░░░░░░░░░░░] 检测中...");
});

// 启动定时更新
setInterval(updateAll, 1000);
setInterval(updateFps, 16);

// 保持脚本运行
setInterval(() => {}, 1000);
