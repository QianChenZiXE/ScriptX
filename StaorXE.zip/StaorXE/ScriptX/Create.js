var folderPath = "/sdcard/ScriptX";
var folder = new java.io.File(folderPath);
if (!folder.exists()) {
    var success = folder.mkdirs();
    if (success) {
        //console.log("文件夹已成功创建：" + folderPath);
    } else {
        //console.log("文件夹创建失败：" + folderPath);
    }
} else {
    //console.log("文件夹已存在：" + folderPath);
}
