// 定义一个函数用于点击指定文本的按键
function clickKeyByText(text) {
    className("android.widget.TextView").text(text).findOne().click();
    sleep(100);
}

// 定义一个函数用于切换大写锁定状态
function toggleCapsLock() {
    id("btn_caps_lock").findOne().click();
    sleep(100);
}

// 主逻辑部分
// 大写锁定
toggleCapsLock();
// 点击键盘 Q
clickKeyByText("Q");
// 切换小写
toggleCapsLock();
// 点击键盘 i
clickKeyByText("i");
// 点击键盘 a
clickKeyByText("a");
// 点击键盘 n
clickKeyByText("n");
// 大写锁定
toggleCapsLock();
// 点击键盘 C
clickKeyByText("C");
// 切换小写
toggleCapsLock();
// 点击键盘 h
clickKeyByText("h");
// 点击键盘 e
clickKeyByText("e");
// 点击键盘 n
clickKeyByText("n");
// 大写锁定
toggleCapsLock();
// 点击键盘 Z
clickKeyByText("Z");
// 切换小写
toggleCapsLock();
// 点击键盘 i
clickKeyByText("i");
// 大写锁定
toggleCapsLock();
// 点击键盘 X
clickKeyByText("X");
// 点击键盘 E
clickKeyByText("E");

// 点击确认按键
id("btn_letter_ok").findOne().click();
